## Anchor gate: plan · lint-k-2

Run `plan-20261013T010912Z-lint-k-2`, model `jev-1.13.0`, threshold 0.6. Counts: underspecified 2, satisfied 4, not_applicable 3.

> **lint-k-2 · ANC-006 · underspecified** Anchor: Optional consumer policy must be opt-in: sc-lint enforces it when supplied and preserves that policy's prior result when absent. You said (Session 01a12885-fd21-7043-a747-0d6f9e4d9869: Rand approved the four proposed constraints (optional policy manifests, compatibility, concrete gap closure, minimal scope) with: yes, those are all aligned with the goals. Pending live rubric, not gate-ready. Rand approved the exact pass/fail examples in anchor-fixture-review.md after opening that file in VS Code (approval: anchor-fixture-approval.json). The examples clarify the previously approved intent, not new goals., Oct 12): "I would make these optional if possible, if the manifest/allow list exists, it is used, if it is absent then current behavior." Jev was not confident (min confidence 0.49); the anchor or the bead may be underspecified. (leaning: not_addressed)
>   Low: compliance `addressed` answered no at 0.49.

> **lint-k-2 · ANC-007 · underspecified** Anchor: Existing simpler consumers must continue to run sc-lint without atm-core-specific configuration. You said (Session 01a12885-fd21-7043-a747-0d6f9e4d9869: Rand approved the four proposed constraints (optional policy manifests, compatibility, concrete gap closure, minimal scope) with: yes, those are all aligned with the goals. Pending live rubric, not gate-ready. Rand approved the exact pass/fail examples in anchor-fixture-review.md after opening that file in VS Code (approval: anchor-fixture-approval.json). The examples clarify the previously approved intent, not new goals., Oct 12): "atm-core is the promary consumer of sc-lint-boundary.  other consumers use it, but they are much simpler boundary problems." Jev was not confident (min confidence 0.49); the anchor or the bead may be underspecified. (leaning: satisfied)
>   Low: compliance `addressed` answered yes at 0.49.



## Anchor gate: plan · lint-k-2

Run `plan-20261013T011550Z-lint-k-2`, model `jev-1.13.0`, threshold 0.6. Counts: satisfied 6, not_applicable 3.

All judged anchors are satisfied or not applicable.



Plan clarifications and growth authority are recorded in triage-*.json alongside these runs. All cite locked anchors predating the failed run; anchors and questions were not changed during plan remediation.
