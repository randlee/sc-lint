## Anchor gate: plan · lint-k-8 - k-8: external-tool-reliability

Run `plan-20261013T011457Z-lint-k-8`, model `jev-1.13.0`, threshold 0.6. Counts: underspecified 4, satisfied 4, not_applicable 1.

> **lint-k-8 · ANC-003 · underspecified** Anchor: Phase K tool logic must use Rust when Rust fits the tool's sc-lint crate boundary. You said (Phase K planning, session 01a12885-fd21-7043-a747-0d6f9e4d9869 Rand approved the exact pass/fail examples in anchor-fixture-review.md after opening that file in VS Code (approval: anchor-fixture-approval.json). The examples clarify the previously approved intent, not new goals., Oct 12): "We should implement tools in rust as appropriate w/ minimal python bindings." Jev was not confident (min confidence 0.38); the anchor or the bead may be underspecified. (leaning: not_applicable)
>   Low: relevance `relevant` answered no at 0.38.

> **lint-k-8 · ANC-005 · underspecified** Anchor: Phase K lint behavior must support consumer repositories beyond atm-core without hard-coded atm-core repository identities or policies. You said (Phase K planning, session 01a12885-fd21-7043-a747-0d6f9e4d9869 Rand approved the exact pass/fail examples in anchor-fixture-review.md after opening that file in VS Code (approval: anchor-fixture-approval.json). The examples clarify the previously approved intent, not new goals., Oct 12): "sc-lint is a general purpose linting tool that is used on many repos." Jev was not confident (min confidence 0.46); the anchor or the bead may be underspecified. (leaning: satisfied)
>   Low: compliance `addressed` answered yes at 0.46.

> **lint-k-8 · ANC-006 · underspecified** Anchor: Optional consumer policy must be opt-in: sc-lint enforces it when supplied and preserves that policy's prior result when absent. You said (Session 01a12885-fd21-7043-a747-0d6f9e4d9869: Rand approved the four proposed constraints (optional policy manifests, compatibility, concrete gap closure, minimal scope) with: yes, those are all aligned with the goals. Pending live rubric, not gate-ready. Rand approved the exact pass/fail examples in anchor-fixture-review.md after opening that file in VS Code (approval: anchor-fixture-approval.json). The examples clarify the previously approved intent, not new goals., Oct 12): "I would make these optional if possible, if the manifest/allow list exists, it is used, if it is absent then current behavior." Jev was not confident (min confidence 0.51); the anchor or the bead may be underspecified. (leaning: not_applicable)
>   Low: relevance `relevant` answered no at 0.51.

> **lint-k-8 · ANC-007 · underspecified** Anchor: Existing simpler consumers must continue to run sc-lint without atm-core-specific configuration. You said (Session 01a12885-fd21-7043-a747-0d6f9e4d9869: Rand approved the four proposed constraints (optional policy manifests, compatibility, concrete gap closure, minimal scope) with: yes, those are all aligned with the goals. Pending live rubric, not gate-ready. Rand approved the exact pass/fail examples in anchor-fixture-review.md after opening that file in VS Code (approval: anchor-fixture-approval.json). The examples clarify the previously approved intent, not new goals., Oct 12): "atm-core is the promary consumer of sc-lint-boundary.  other consumers use it, but they are much simpler boundary problems." Jev was not confident (min confidence 0.20); the anchor or the bead may be underspecified. (leaning: not_applicable)
>   Low: relevance `relevant` answered no at 0.36.
>   Low: compliance `addressed` answered yes at 0.20.



## Anchor gate: plan · lint-k-8

Run `plan-20261013T011656Z-lint-k-8`, model `jev-1.13.0`, threshold 0.6. Counts: underspecified 1, satisfied 6, not_applicable 2.

> **lint-k-8 · ANC-007 · underspecified** Anchor: Existing simpler consumers must continue to run sc-lint without atm-core-specific configuration. You said (Session 01a12885-fd21-7043-a747-0d6f9e4d9869: Rand approved the four proposed constraints (optional policy manifests, compatibility, concrete gap closure, minimal scope) with: yes, those are all aligned with the goals. Pending live rubric, not gate-ready. Rand approved the exact pass/fail examples in anchor-fixture-review.md after opening that file in VS Code (approval: anchor-fixture-approval.json). The examples clarify the previously approved intent, not new goals., Oct 12): "atm-core is the promary consumer of sc-lint-boundary.  other consumers use it, but they are much simpler boundary problems." Jev was not confident (min confidence 0.56); the anchor or the bead may be underspecified. (leaning: satisfied)
>   Low: relevance `relevant` answered yes at 0.56.



## Anchor gate: plan · lint-k-8

Run `plan-20261013T011845Z-lint-k-8`, model `jev-1.13.0`, threshold 0.6. Counts: satisfied 7, not_applicable 2.

All judged anchors are satisfied or not applicable.



Plan clarifications and growth authority are recorded in triage-*.json alongside these runs. All cite locked anchors predating the failed run; anchors and questions were not changed during plan remediation.
