# ANC-005 plan questions

Accepted independent tuning; question digest 8fc2727932433a6242a2c9b5ecf5b08e2c71403a0aa4de1e5c3aa3cc4ec6bc27.

```json
{
  "questions": {
    "relevant": {
      "type": "choice",
      "instructions": "Assess relevant for the single work item against this approved requirement: Phase K lint behavior must support consumer repositories beyond atm-core without hard-coded atm-core repository identities or policies. Classify whether this item operates in the anchor scope even if its method is missing or wrong. Explicit absence of the governing trigger is out of scope.",
      "criteria": {
        "yes": "The work touches consumer-facing Phase K lint behavior, configuration, or tools across repositories, including investigations and incomplete changes.",
        "no": "The work is unrelated or explicitly says no consumer-facing lint behavior, configuration, or tool behavior is touched.",
        "unclear": "The text does not establish whether this subject is touched."
      }
    },
    "addressed": {
      "type": "choice",
      "instructions": "Assess addressed for the single work item against this approved requirement: Phase K lint behavior must support consumer repositories beyond atm-core without hard-coded atm-core repository identities or policies. Classify whether its planned behavior explicitly carries the complete requirement. Mere topic naming or an incomplete requirement does not carry it.",
      "criteria": {
        "yes": "behavior supports repositories beyond atm-core, with no hard-coded atm-core repository identity or private policy; consumer configuration may select policies and generic repository-neutral rules may need none. Equivalent substantive wording counts.",
        "no": "The behavior is absent, merely topical, incomplete, or replaced by an incompatible alternative.",
        "unclear": "The text alludes to the specific behavior but its meaning is unresolved."
      }
    },
    "contradicted": {
      "type": "choice",
      "instructions": "Assess contradicted for the single work item against this approved requirement: Phase K lint behavior must support consumer repositories beyond atm-core without hard-coded atm-core repository identities or policies. Classify only an explicit incompatible decision. Missing description is not an incompatible decision.",
      "criteria": {
        "yes": "the behavior depends on hard-coded atm-core identity OR embeds atm-core-specific policy, even without an identity check.",
        "no": "No incompatible behavior is stated; silence and missing detail alone count no.",
        "unclear": "Stated behavior might be incompatible but cannot be resolved."
      }
    }
  }
}
```

Canonical tuning history SHA-256: 76093b38adf634cbb2cd8c4489cf0b282a7871244e2eaaa1ac39664b15deac20

```tuning-history
{"events":[{"authority":{"anchor_id":"ANC-005","anchor_record_sha256":"25e58997d25838ca94908590dad7a68598adcb0da9e7f94067f9ba58a412a4b7","anchor_version":2,"intent_id":"phase-k-intent","intent_sha256":"076f46ac1fba20eb8a57b51159e3f8128571dd3186053103daf4b5494813d2c3","intent_version":3},"candidate":{"candidate_id":"v3","question_sha256":"8fc2727932433a6242a2c9b5ecf5b08e2c71403a0aa4de1e5c3aa3cc4ec6bc27"},"decision":{"question_set_sha256":"8fc2727932433a6242a2c9b5ecf5b08e2c71403a0aa4de1e5c3aa3cc4ec6bc27","reason_code":"TOURNAMENT.ACCEPTED","status":"sealed"},"event":"question_set_sealed","event_index":1,"evidence":{"canonical_request_sha256":["bdac185436bcb08e1f0d3b0fbe5ddddd37c8f0160d522f0c21da3794ee18492e","bdac185436bcb08e1f0d3b0fbe5ddddd37c8f0160d522f0c21da3794ee18492e","59d482678d88a343b720844b649c9b7a6e6b7551e6e331b71f427e795d16f7e0","59d482678d88a343b720844b649c9b7a6e6b7551e6e331b71f427e795d16f7e0","5267dc75d5ed665ae54ee7a5345790a02383bd8bc774dcd784f653c8e9edd6ac","5267dc75d5ed665ae54ee7a5345790a02383bd8bc774dcd784f653c8e9edd6ac","1bef32b6ac994dda846cc0c7ff1a5fc955afc1925739b703a6ca96582a4e16d7","1bef32b6ac994dda846cc0c7ff1a5fc955afc1925739b703a6ca96582a4e16d7","ac771ee7f01203368cf922e2ca23bff64ea9d54d5437b3c9d83266f4bb04ce14","ac771ee7f01203368cf922e2ca23bff64ea9d54d5437b3c9d83266f4bb04ce14","f1fa2ae50c4799599428976fbf432f4d4711342ea1e6cf29d546e1e07c00910d","f1fa2ae50c4799599428976fbf432f4d4711342ea1e6cf29d546e1e07c00910d","677ac7e84cf1bfd621171a5020de263f18955540aa2f2bc1ec662878d49364ea","677ac7e84cf1bfd621171a5020de263f18955540aa2f2bc1ec662878d49364ea","12e102cdcf87de9bd5bf9ae973f6e9c3e191ece124cececa2954bf5aa7b67f7f","12e102cdcf87de9bd5bf9ae973f6e9c3e191ece124cececa2954bf5aa7b67f7f","23cc6fbf801aee73357098afd5a4db9db4a3c46a758d6072b15200fcabe1e485","23cc6fbf801aee73357098afd5a4db9db4a3c46a758d6072b15200fcabe1e485","05599754a11ed2abe5fd289a7a56322763ecbe1f3004e7adb4c1d8d654d43960","05599754a11ed2abe5fd289a7a56322763ecbe1f3004e7adb4c1d8d654d43960","6d67334a86f0ebc9153e528f3909a4ce5eb1bf8c38baf33cdcaab094f8a4fe87","6d67334a86f0ebc9153e528f3909a4ce5eb1bf8c38baf33cdcaab094f8a4fe87"],"raw_response_sha256":["092e76e215dbd35ae7d4ab807c76316409f094d122d78f5f15a2c7a157e39bc9","a596d85c7b97c7f7e02a089b22fcf94b19fa31af34841980249ae306649a2696","1aa85a3a33c2731c2b7e773d234b215f0760b712d902dbb48582abe54f9d65f0","1aa85a3a33c2731c2b7e773d234b215f0760b712d902dbb48582abe54f9d65f0","8e6179da1e1a683460be5306edac2128aa7101549bef819fa6830574796430dd","8e6179da1e1a683460be5306edac2128aa7101549bef819fa6830574796430dd","8b3413a6b53eb9cb9e7ca18ca914b09902737b308f44a7ad4e60dba7b7a4524f","8b3413a6b53eb9cb9e7ca18ca914b09902737b308f44a7ad4e60dba7b7a4524f","482800cb1bacef86c46aa05c3a120ebbe7bbe06f106b2b277583003f9429dec7","67476a9fec92a1ee70656272e2f44e7fcdc2c1d08a1d253a569528c2012f9feb","83ea9a121da81a2611e820df55fd92e2690a45d3950ed0968de7031b6bb2e056","83ea9a121da81a2611e820df55fd92e2690a45d3950ed0968de7031b6bb2e056","b3836a4fe91c5decc9567fd1315741152895423f0df8b64e71af45ce131bd717","b3836a4fe91c5decc9567fd1315741152895423f0df8b64e71af45ce131bd717","2ad774c5e2a5253d91f217cc2256afc4e6edc743b393e64823a5cfac3c840620","bf823c9cac2da8919e62aae41dfb0601f75d1a05a90eb5b8597d34025145f3ec","316eaf02bbd41ce9c28f53fd566336214d2dc85639a704e7a285e8a93838d55d","4109f5735a3814e12bed3e7c5caa8184a71e976852c75f170b049b2e21cfea3a","b8d94681f89c1e1812b7b2a51935a1d1fe43e69ed3c74cb1474347cb4632c484","b8d94681f89c1e1812b7b2a51935a1d1fe43e69ed3c74cb1474347cb4632c484","f3350016e1bb407e964b9bd79815c454d6dd073eb80ea7a173e3757a21a5f303","f3350016e1bb407e964b9bd79815c454d6dd073eb80ea7a173e3757a21a5f303"],"run_ids":["ANC-005-plan-v3__approved-pass__r1","ANC-005-plan-v3__approved-pass__r2","ANC-005-plan-v3__approved-fail__r1","ANC-005-plan-v3__approved-fail__r2","ANC-005-plan-v3__paraphrase__r1","ANC-005-plan-v3__paraphrase__r2","ANC-005-plan-v3__silent__r1","ANC-005-plan-v3__silent__r2","ANC-005-plan-v3__topical__r1","ANC-005-plan-v3__topical__r2","ANC-005-plan-v3__direct-conflict__r1","ANC-005-plan-v3__direct-conflict__r2","ANC-005-plan-v3__irrelevant__r1","ANC-005-plan-v3__irrelevant__r2","ANC-005-plan-v3__boundary__r1","ANC-005-plan-v3__boundary__r2","ANC-005-plan-v3__nonfixture-policy__r1","ANC-005-plan-v3__nonfixture-policy__r2","ANC-005-plan-v3__policy-no-name__r1","ANC-005-plan-v3__policy-no-name__r2","ANC-005-plan-v3__generic-default__r1","ANC-005-plan-v3__generic-default__r2"]},"oracle":{"case_count":11,"case_ids":["approved-pass","approved-fail","paraphrase","silent","topical","direct-conflict","irrelevant","boundary","nonfixture-policy","policy-no-name","generic-default"],"repeat_count":2,"sha256":"757f0d45ba097ba018ff9f8eea1431814c382af090f8d10bcf555719f8768d01"},"previous_event_sha256":null,"protocol_version":"plan-anchor/question-tournament/2.0.0","score":{"confidence":{"cells_at_or_above_threshold":33,"mean":0.9767,"median":1.0,"minimum":0.85,"p10":0.92,"threshold":0.8,"total_cells":33},"exact_role_cells":33,"exact_semantic_verdicts":11,"regressions":0,"stable_cases":11,"total_cases":11,"total_role_cells":33,"total_semantic_verdicts":11},"supersedes":{"decision_sha256":"ffcf9dc336c8ef1dbe26b6a35a1a891c08903d3091f4641c447d95030a4293ff","protocol_version":"initial-empty-history"}}],"history_id":"ANC-005-plan","schema":"plan-anchor/tuning-history/2"}
```
