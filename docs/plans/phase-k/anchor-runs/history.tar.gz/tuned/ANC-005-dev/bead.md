# ANC-005 dev questions

Accepted independent tuning; question digest 4950907c99c4922f4d1d9884dc37fb557700c6e80c32f6a26efe1f86a18690ec.

```json
{
  "questions": {
    "relevant": {
      "type": "choice",
      "instructions": "Use the specific behavioral distinction in the criteria to judge `item.text`; do not infer missing behavior. Is the governed work present? Investigating it or omitting its constraint still touches its subject.",
      "criteria": {
        "yes": "Classify yes when the work touches consumer-facing Phase K lint behavior, configuration, or tools across repositories, including investigations and incomplete changes.",
        "no": "Classify no when the work is unrelated or explicitly says no consumer-facing lint behavior, configuration, or tool behavior is touched.",
        "unclear": "Classify unclear when the text does not establish whether this subject is touched."
      }
    },
    "implemented": {
      "type": "choice",
      "instructions": "Use the specific behavioral distinction in the criteria to judge `item.text`; do not infer missing behavior. Does the described result implement the complete obligation, including every conditional branch? Evidence presence is separate.",
      "criteria": {
        "yes": "Classify yes when behavior supports repositories beyond atm-core, with no hard-coded atm-core repository identity or private policy; consumer configuration may select policies and generic repository-neutral rules may need none. Equivalent substantive wording counts.",
        "no": "Classify no when the behavior is absent, merely topical, incomplete, or replaced by an incompatible alternative.",
        "unclear": "Classify unclear when the text alludes to the specific behavior but its meaning is unresolved."
      }
    },
    "violated": {
      "type": "choice",
      "instructions": "Use the specific behavioral distinction in the criteria to judge `item.text`; do not infer missing behavior. Does the described result affirmatively break the obligation? Silence alone says no.",
      "criteria": {
        "yes": "Classify yes when the behavior depends on hard-coded atm-core identity OR embeds atm-core-specific policy, even without an identity check.",
        "no": "Classify no when no incompatible behavior is stated; silence and missing detail alone count no.",
        "unclear": "Classify unclear when stated behavior might be incompatible but cannot be resolved."
      }
    },
    "evidenced": {
      "type": "choice",
      "instructions": "Use the specific behavioral distinction in the criteria to judge `item.text`; do not infer missing behavior. Are concrete artifacts or observed checks supplied for the governed behavior? Evidence may demonstrate failure as well as success.",
      "criteria": {
        "yes": "Classify yes when an inspectable code or diff excerpt, specific artifact content, or a concrete command/test observation substantiates the rule behavior.",
        "no": "Classify no when only assertions, intentions, topic mentions, or unsubstantiated claims are supplied; no concrete behavioral evidence.",
        "unclear": "Classify unclear when a cited artifact cannot be connected to the relevant behavior."
      }
    }
  }
}
```

Canonical tuning history SHA-256: ce7640abacfcfc9bc38d21b4d4bcecd18e000d441a2739e8a5a1611c075ef489

```tuning-history
{"events":[{"authority":{"anchor_id":"ANC-005","anchor_record_sha256":"25e58997d25838ca94908590dad7a68598adcb0da9e7f94067f9ba58a412a4b7","anchor_version":2,"intent_id":"phase-k-intent","intent_sha256":"076f46ac1fba20eb8a57b51159e3f8128571dd3186053103daf4b5494813d2c3","intent_version":3},"candidate":{"candidate_id":"v4","question_sha256":"4950907c99c4922f4d1d9884dc37fb557700c6e80c32f6a26efe1f86a18690ec"},"decision":{"question_set_sha256":"4950907c99c4922f4d1d9884dc37fb557700c6e80c32f6a26efe1f86a18690ec","reason_code":"TOURNAMENT.ACCEPTED","status":"sealed"},"event":"question_set_sealed","event_index":1,"evidence":{"canonical_request_sha256":["a8be397831829df9e3f1880b5b0ea89d00d5bc1d1724c340ace1816b3dab756a","a8be397831829df9e3f1880b5b0ea89d00d5bc1d1724c340ace1816b3dab756a","2e6ba128c65fa74e51be58d15df0ca4b9c316149bad0f7e2f0496c1e5d6960bc","2e6ba128c65fa74e51be58d15df0ca4b9c316149bad0f7e2f0496c1e5d6960bc","c851e0a8abf07944f0ca8984b0b64fb13eff6df47b7bc672a63bd0cc860d45f1","c851e0a8abf07944f0ca8984b0b64fb13eff6df47b7bc672a63bd0cc860d45f1","9cce743b3bbb5351410c5263fa0aedcd60fb70e6364725defa33c257ec6339c4","9cce743b3bbb5351410c5263fa0aedcd60fb70e6364725defa33c257ec6339c4","13d586134e84bdc6a64bf46479c30042ce2bfd6355c88b87c0bc20686ae54a63","13d586134e84bdc6a64bf46479c30042ce2bfd6355c88b87c0bc20686ae54a63","df0271044873dbd850d7ac65f79463446df1453f0c8c5d389fd7b2a1c1511c24","df0271044873dbd850d7ac65f79463446df1453f0c8c5d389fd7b2a1c1511c24","6e8864c2769e94a114485b9c24b6598cf93751d76be9c63c5e95321791df14e5","6e8864c2769e94a114485b9c24b6598cf93751d76be9c63c5e95321791df14e5","693cef0294d39d1d6fd7c83306e2904a4f269d83cfa9ff8fb163a7fbc113c970","693cef0294d39d1d6fd7c83306e2904a4f269d83cfa9ff8fb163a7fbc113c970","bf102169aed3349d5e401079070c55fb53649599bd06333c6fe3a1573970db4e","bf102169aed3349d5e401079070c55fb53649599bd06333c6fe3a1573970db4e","454a7afe30d19f002a059e099e459da8126e0f6f4d40454d0a74245788592c55","454a7afe30d19f002a059e099e459da8126e0f6f4d40454d0a74245788592c55","d560e76f4957467d5dbfb49b0f32d045ce9b2c70ebf1f06b1e4b0e69c3ca57ba","d560e76f4957467d5dbfb49b0f32d045ce9b2c70ebf1f06b1e4b0e69c3ca57ba","e3f5e2e54e9f3befcd72df4436d0f155f097979ad79d2cbba7afc9d5d8762971","e3f5e2e54e9f3befcd72df4436d0f155f097979ad79d2cbba7afc9d5d8762971","ee41ce14cb456f2df969d2040d77e76cb18ea7b2689843ccda4a41205a5fd4fe","ee41ce14cb456f2df969d2040d77e76cb18ea7b2689843ccda4a41205a5fd4fe"],"raw_response_sha256":["92c70ff8d8d3a23d41b26a470bd8bfb406993e6d40cb2fcee4afb140facf0e01","b2c09b2d77419d75e01ae6f7e8ed3a8d4b1d33e11b84e1d9f8f777018c1509c9","4eac9ea6a5be438c7b8f5eb3ac973a13000602f4aaec15c57654b6e6cafbbc51","d440d07e3e416c38efc4ec0fad96d25dbc90a62d0e5934a641fb42abfde695b1","19b2934b8c2110095def5bbd3482ba77d00fff45b65aa8321cdf7054602cf302","d1669c62f212adf1c5b74716481512081ddfd6b80373d9122712f785fa4db55d","54ac5e4bed21308312eb9c7effe10830cdec613c472737956d3f798055e5fe72","7241b0d8f5fc0b455eb03e815bade901d2e264ce253319a04116c668f1f96912","1e91acfc3cc1f7c123b7f24f81c56a39585cfaea9640ab7d798c31a0b81cd6ce","891c090c460fe7befef4cad8b55cf66f832a84e5535e0f396d00971697663baa","21eda3e77fbebcb90d5db3438a65c995b8b3ef554b4dd20a1c1b159896ba5eb8","71e6c33c360d5085f6a5e7198122d55db84f16ed1b4ba121041852d8c056cfb5","c3be3d6dafb6245bb7fdf5f611d2736bbc242689c93478742134a08335b9bd7f","b80a5ecb3b482cc64791fdcb6e81638114fb5695e3d769b88b229285ffb8d457","01f28e223ab8b78209ce0ae2955bd2273dc98a614ed27c013e80e0a53b4705d0","4c586360c57138ce94a9caf6d53ae69090b0e4edec632ebd13f4a10cee977018","55b2d55be083ad8bdaa8842a5ff520a0438b0760de0061e2cbe37e0025656dcb","87a8401fcc42aae005e643419feea3964a2036c581c936a036a7b621f13bc270","e41ad25011427d6f4cc96e28b6c7a3150868c460acbc41f4b0c939d7c8e68913","027c24bcd20fd2ed51beeea57db0a77213a70a2257fc6f4484d0cb246bdfe400","64b0740b8dff687e80a1a0af4493f843f65060be9cfa27f8254d032ead95f61c","bb50bffaf123a838c21da0e6f77a4e9e1fcd6fc0cb860b5e251423952b703fdd","e71f76b98c3ce2234834d8a030267b67aab0ab9daa3240f3e36cf80443b9bf0d","e71f76b98c3ce2234834d8a030267b67aab0ab9daa3240f3e36cf80443b9bf0d","68d112e0c6d085508c3beee2deeb3b5b7f46d5d619901b5ee7386064c3e3ca30","68d112e0c6d085508c3beee2deeb3b5b7f46d5d619901b5ee7386064c3e3ca30"],"run_ids":["ANC-005-dev-v4__approved-pass__r1","ANC-005-dev-v4__approved-pass__r2","ANC-005-dev-v4__approved-fail__r1","ANC-005-dev-v4__approved-fail__r2","ANC-005-dev-v4__paraphrase__r1","ANC-005-dev-v4__paraphrase__r2","ANC-005-dev-v4__silent__r1","ANC-005-dev-v4__silent__r2","ANC-005-dev-v4__topical__r1","ANC-005-dev-v4__topical__r2","ANC-005-dev-v4__direct-conflict__r1","ANC-005-dev-v4__direct-conflict__r2","ANC-005-dev-v4__irrelevant__r1","ANC-005-dev-v4__irrelevant__r2","ANC-005-dev-v4__boundary__r1","ANC-005-dev-v4__boundary__r2","ANC-005-dev-v4__nonfixture-policy__r1","ANC-005-dev-v4__nonfixture-policy__r2","ANC-005-dev-v4__policy-no-name__r1","ANC-005-dev-v4__policy-no-name__r2","ANC-005-dev-v4__generic-default__r1","ANC-005-dev-v4__generic-default__r2","ANC-005-dev-v4__concrete-evidence__r1","ANC-005-dev-v4__concrete-evidence__r2","ANC-005-dev-v4__evidenced-conflict__r1","ANC-005-dev-v4__evidenced-conflict__r2"]},"oracle":{"case_count":13,"case_ids":["approved-pass","approved-fail","paraphrase","silent","topical","direct-conflict","irrelevant","boundary","nonfixture-policy","policy-no-name","generic-default","concrete-evidence","evidenced-conflict"],"repeat_count":2,"sha256":"98b68414d6fa3cc10eee60dc0e342977d1482e05ff844b95c425d62a6c98d442"},"previous_event_sha256":null,"protocol_version":"plan-anchor/question-tournament/2.0.0","score":{"confidence":{"cells_at_or_above_threshold":50,"mean":0.9575,"median":0.99,"minimum":0.64,"p10":0.86,"threshold":0.8,"total_cells":52},"exact_role_cells":52,"exact_semantic_verdicts":13,"regressions":0,"stable_cases":13,"total_cases":13,"total_role_cells":52,"total_semantic_verdicts":13},"supersedes":{"decision_sha256":"e6ac64bde6894fc0e8bfd2aa1fe71e8fe075d3a7112359dae3bfd1449a19bf3f","protocol_version":"initial-empty-history"}}],"history_id":"ANC-005-dev","schema":"plan-anchor/tuning-history/2"}
```
