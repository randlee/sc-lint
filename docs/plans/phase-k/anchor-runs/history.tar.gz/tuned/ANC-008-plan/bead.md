# ANC-008 plan questions

Accepted independent tuning; question digest 61eca38adaf20eaffdc1707f35b48b9c69886b9e026d12c2aba9b209604d4f55.

```json
{
  "questions": {
    "relevant": {
      "type": "choice",
      "instructions": "Read `item.text` for applicability to a Phase K sprint that fixes a reported consumer gap; compliance is a separate judgment. Omission or conflict remains relevant. Work explicitly outside the governing subject is not relevant. Decide from the described action and its scope; do not infer missing commitments.",
      "criteria": {
        "yes": "The subject a Phase K sprint that fixes a reported consumer gap is involved, regardless of whether the duty is stated or obeyed.",
        "no": "It is unrelated, or explicitly establishes that the item is not a sprint fixing a reported consumer gap.",
        "unclear": "The governed subject cannot be determined."
      }
    },
    "addressed": {
      "type": "choice",
      "instructions": "Is the anchor-specific behavior present in the planned method or constraint: cite the reporting GitHub issue and include an issue-linked regression test reproducing its reported failure? Topic labels and incomplete descriptions do not carry this duty. Decide from the described action and its scope; do not infer missing commitments.",
      "criteria": {
        "yes": "The text explicitly states cite the reporting GitHub issue and include an issue-linked regression test reproducing its reported failure as a planned action or constraint.",
        "no": "The obligation is omitted, only its topic is mentioned, or an incompatible approach replaces it.",
        "unclear": "The text alludes to compliance but leaves the required behavior uncertain."
      }
    },
    "contradicted": {
      "type": "choice",
      "instructions": "Does `item.text` explicitly reject or defer an issue-linked regression test that reproduces the reported consumer failure within its Phase K gap-fix sprint? Judge incompatible choices only. Omitting discussion of issues or tests is silence, not conflict.",
      "criteria": {
        "yes": "The item deliberately omits the reporting GitHub issue link, deliberately skips or defers reproduction of the reported failure beyond this sprint, or substitutes only a generic success test. Any such explicit incompatible decision counts.",
        "no": "There is no explicit incompatible decision; a missing issue/test discussion by itself does not count.",
        "unclear": "A possibly incompatible decision is described, but it is uncertain whether the required issue-linked failure reproduction is rejected."
      }
    }
  }
}
```

Canonical tuning history SHA-256: 8234480404ce6de892672b5ba247c6cd2a63dc85f62eab33ad24d9fc2d4ddd69

```tuning-history
{"events":[{"authority":{"anchor_id":"ANC-008","anchor_record_sha256":"d66efb6955562ea15f9f333cb6c490fe58be541143bfd2f46181e6b701c04c30","anchor_version":3,"intent_id":"phase-k-intent","intent_sha256":"076f46ac1fba20eb8a57b51159e3f8128571dd3186053103daf4b5494813d2c3","intent_version":3},"candidate":{"candidate_id":"v4","question_sha256":"61eca38adaf20eaffdc1707f35b48b9c69886b9e026d12c2aba9b209604d4f55"},"decision":{"question_set_sha256":"61eca38adaf20eaffdc1707f35b48b9c69886b9e026d12c2aba9b209604d4f55","reason_code":"TOURNAMENT.ACCEPTED","status":"sealed"},"event":"question_set_sealed","event_index":1,"evidence":{"canonical_request_sha256":["9da65b421b4f5008162c0ffedb3b298611015320c2a285c878c4d28cc88c01da","9da65b421b4f5008162c0ffedb3b298611015320c2a285c878c4d28cc88c01da","fb3a108c8c9f62eb5ee853e1513c060a3e22a986e5ea5bfd2e105d6f6a36a31e","fb3a108c8c9f62eb5ee853e1513c060a3e22a986e5ea5bfd2e105d6f6a36a31e","469b84bb23596c6c41658cf8221895a9d84ac51a138d1dd0b105f780d226ef5d","469b84bb23596c6c41658cf8221895a9d84ac51a138d1dd0b105f780d226ef5d","0e8bc88f84bbd4b6e8a79d3e3981a0c1a27965f85025ba2604e7a7a62f4caf50","0e8bc88f84bbd4b6e8a79d3e3981a0c1a27965f85025ba2604e7a7a62f4caf50","8188577f08e587be2df92a9c69c21c3125ba033866c201ba40d9a978d5866ed2","8188577f08e587be2df92a9c69c21c3125ba033866c201ba40d9a978d5866ed2","016871aa54be67af55e69a3ce6f68f428375c9da9b2a9f71ecf72cb86ad5d066","016871aa54be67af55e69a3ce6f68f428375c9da9b2a9f71ecf72cb86ad5d066","92c900739f953b152b4b7fa97c76ec016c64bffc40fc6eb2ad8dfe0de53a451f","92c900739f953b152b4b7fa97c76ec016c64bffc40fc6eb2ad8dfe0de53a451f","2dc3b6f2074a04b1688b2af17dc5110f1af0392435230f4000c3e3cc7e5b63c7","2dc3b6f2074a04b1688b2af17dc5110f1af0392435230f4000c3e3cc7e5b63c7","1ebfb8d3efbd78b6c9b6fbc73f61076cedc94c282365582004ffaf96cd420b71","1ebfb8d3efbd78b6c9b6fbc73f61076cedc94c282365582004ffaf96cd420b71","96dc301433b89fab9e7255b3eee9409228b6795b5cb0a2e34dca939fd6a20a22","96dc301433b89fab9e7255b3eee9409228b6795b5cb0a2e34dca939fd6a20a22","f418e38c2b1ba7c34c190e9faa3b4df5d189684f056dfcc1b102898a1bb57270","f418e38c2b1ba7c34c190e9faa3b4df5d189684f056dfcc1b102898a1bb57270","7878f30a04ac7408f41baae93c6e6cfc9b3272808c5777ece75f01cffc10110e","7878f30a04ac7408f41baae93c6e6cfc9b3272808c5777ece75f01cffc10110e"],"raw_response_sha256":["c8aac4bd383f4925b8acd245e1e70af764e5b97d42ab54a7711f45c490003b85","8146e86649cd9859d90a669475dc1d375d6acaae23f96749c5af444a7662a66d","7ee135d82a10a5bfdf41253554eeaf5ba5db3c9f96beb82e52bae7166a7115db","8e769126d4323119eabd86619746e6d1554cc7da2dfe058d7622abd2d458834b","128e9e3ee93990ea632b7c139c9efa3d222cbe9f33649a603acf99dfa2ffd4a0","128e9e3ee93990ea632b7c139c9efa3d222cbe9f33649a603acf99dfa2ffd4a0","73c9ae3d59a9509a5b958f6b03f0f68c90af9c9dd33f1613f7fb8f31d647c787","9f9accbbe37e55b655df85552b30c74f74576a37ad0efa69c5b543b1b6116123","6551862e3592497989b361c3cfbaa6cf4f8d843961b0d6235d88c997bc43b991","704520a98944ea6cfc6228f9732abb59bb4be8886df267ff5e82134b6a297a64","ee6a0dd4249700d226348da536929d8a2ea6c71cfb6dcd41efdc731b4b817211","c099fb20dcacb287f7bde75eee7d5f62bf7ae7098165818f7495a3e530773426","d3646612113830547973fa0fcb8d5fed00495844a09d9ce5668466b196e53535","e1d79ec75822e85314a50b2d70210db275278ded4dc72eec5f034b4e72e3b174","c53e53aa43943eee9d935d18eb07a3c8421be77804d9512af538261f3edd997d","66e3b5c04d83cba935ce7e9cbe186e88fd95e2cb250ee015c214a0ea3eb3b49d","91eac34bbf82926e138d2c632ca2aa010abf867726f334ec22174265b354a821","6d5b0ca9ab169ad88e695b8eca681bd44871ff7641792669fd41141a9946b9c1","de0b6f9812957540fe5f09411f75a7eb00774b2dcefcb9872ac4336e3e2b6e70","09df8d911f4b55a884e49edcc8ccaa282776f69e9ad6099885aca66599411295","ff24a482fdef2c9196dabad42feb85316906b8e3b19b8297756cf9c728a69a07","b6b8bc2ed5f5db134054637071eddab6234411cbb3fa3ead1830b98a63760781","b1632e92b8b8b83ee6827e8b89775db89adc702ff17459fffeed098311cf54c9","b1632e92b8b8b83ee6827e8b89775db89adc702ff17459fffeed098311cf54c9"],"run_ids":["ANC-008-plan-v4__approved-pass__r1","ANC-008-plan-v4__approved-pass__r2","ANC-008-plan-v4__approved-fail__r1","ANC-008-plan-v4__approved-fail__r2","ANC-008-plan-v4__minimal-compliant__r1","ANC-008-plan-v4__minimal-compliant__r2","ANC-008-plan-v4__silent__r1","ANC-008-plan-v4__silent__r2","ANC-008-plan-v4__topical__r1","ANC-008-plan-v4__topical__r2","ANC-008-plan-v4__direct-conflict__r1","ANC-008-plan-v4__direct-conflict__r2","ANC-008-plan-v4__irrelevant__r1","ANC-008-plan-v4__irrelevant__r2","ANC-008-plan-v4__boundary__r1","ANC-008-plan-v4__boundary__r2","ANC-008-plan-v4__boundary-gap-compliant__r1","ANC-008-plan-v4__boundary-gap-compliant__r2","ANC-008-plan-v4__missing-issue-link-conflict__r1","ANC-008-plan-v4__missing-issue-link-conflict__r2","ANC-008-plan-v4__partial-omission__r1","ANC-008-plan-v4__partial-omission__r2","ANC-008-plan-v4__future-reproduction__r1","ANC-008-plan-v4__future-reproduction__r2"]},"oracle":{"case_count":12,"case_ids":["approved-pass","approved-fail","minimal-compliant","silent","topical","direct-conflict","irrelevant","boundary","boundary-gap-compliant","missing-issue-link-conflict","partial-omission","future-reproduction"],"repeat_count":2,"sha256":"3d8a6a32183dfb57d5fa7c7e5271748a663ab06e705970d8a9b136ffec97679d"},"previous_event_sha256":null,"protocol_version":"plan-anchor/question-tournament/2.0.0","score":{"confidence":{"cells_at_or_above_threshold":35,"mean":0.9683,"median":1.0,"minimum":0.72,"p10":0.89,"threshold":0.8,"total_cells":36},"exact_role_cells":36,"exact_semantic_verdicts":12,"regressions":0,"stable_cases":12,"total_cases":12,"total_role_cells":36,"total_semantic_verdicts":12},"supersedes":{"decision_sha256":"f24f13bbfd6b7613279a09fb785a71b81ea9bcf229489d9244f84cf7e8d11cf3","protocol_version":"initial-empty-history"}}],"history_id":"ANC-008-plan","schema":"plan-anchor/tuning-history/2"}
```
