# ANC-007 plan questions

Accepted independent tuning; question digest 402a1ed5fed16b147b1738bde776635fc67b9877c75bf5c0e69136aa9b3683b8.

```json
{
  "questions": {
    "relevant": {
      "type": "choice",
      "instructions": "Judge only whether `item.text` touches consumer configuration or boundary-check compatibility for existing simpler sc-lint consumers. Omission or conflict remains relevant. Work explicitly outside the governing subject is not relevant.",
      "criteria": {
        "yes": "It changes, investigates, or defines consumer configuration or boundary-check compatibility for existing simpler sc-lint consumers.",
        "no": "It is unrelated, or explicitly establishes that the item does not change consumer configuration or boundary checking.",
        "unclear": "The governed subject cannot be determined."
      }
    },
    "addressed": {
      "type": "choice",
      "instructions": "Does `item.text` state that existing simpler consumers can run the sc-lint behavior under discussion without needing atm-core-specific configuration? Judge explicit inclusion of this compatibility obligation. A description of preserved behavior or its planned preservation counts; ordinary optional consumer settings and intended bug-fix result changes are allowed. Do not infer preservation from unrelated work.",
      "criteria": {
        "yes": "The item explicitly says a simpler consumer runs, remains able to run, or will run the relevant sc-lint check or CLI without an atm-core manifest or other atm-core-specific configuration. This may describe one concrete simpler consumer or general compatibility.",
        "no": "The item omits that compatibility content, only mentions consumers, requires atm-core configuration, or concerns unrelated work without stating the obligation.",
        "unclear": "The text discusses continued operation but leaves it uncertain whether atm-core-specific configuration is required."
      }
    },
    "contradicted": {
      "type": "choice",
      "instructions": "Does `item.text` state an incompatible planned choice: make running sc-lint by an existing simpler consumer depend on any atm-core-specific configuration? Silence or incomplete discussion is not conflict.",
      "criteria": {
        "yes": "It explicitly commits to make running sc-lint by an existing simpler consumer depend on any atm-core-specific configuration.",
        "no": "It contains no incompatible action; silence alone is not a violation.",
        "unclear": "A conflicting action is possible but cannot be established."
      }
    }
  }
}
```

Canonical tuning history SHA-256: 48ad8a85cdc6f5c9fa59c1b3414a9979f9f6db123624726ccf76367a9dee633e

```tuning-history
{"events":[{"authority":{"anchor_id":"ANC-007","anchor_record_sha256":"82b735dff3a1028e677f8f1ccc4242f194c9f48aaf07d4c67f7ddf54eebb3207","anchor_version":3,"intent_id":"phase-k-intent","intent_sha256":"076f46ac1fba20eb8a57b51159e3f8128571dd3186053103daf4b5494813d2c3","intent_version":3},"candidate":{"candidate_id":"v4","question_sha256":"402a1ed5fed16b147b1738bde776635fc67b9877c75bf5c0e69136aa9b3683b8"},"decision":{"question_set_sha256":"402a1ed5fed16b147b1738bde776635fc67b9877c75bf5c0e69136aa9b3683b8","reason_code":"TOURNAMENT.ACCEPTED","status":"sealed"},"event":"question_set_sealed","event_index":1,"evidence":{"canonical_request_sha256":["7c6c23bcf65090301fb97da81871bc18a33d333bb7d835b2199a764995271a0c","7c6c23bcf65090301fb97da81871bc18a33d333bb7d835b2199a764995271a0c","13d22ccf3ef6aa07ef4c2c34a8b4a9319b8acffbb075e018994415058f623743","13d22ccf3ef6aa07ef4c2c34a8b4a9319b8acffbb075e018994415058f623743","50bd82ccae3fb6cef48c6cb0297f02960709341315e69bf992b1e4c7d803e156","50bd82ccae3fb6cef48c6cb0297f02960709341315e69bf992b1e4c7d803e156","7e2d216d32e58afb2f8ddaa1afaa32447d0312f1bec8b64e9226f9e62e265c2a","7e2d216d32e58afb2f8ddaa1afaa32447d0312f1bec8b64e9226f9e62e265c2a","005d7f62d44165440f73a6c79df2b18276e864961c40bb49ff9981c58a9ee715","005d7f62d44165440f73a6c79df2b18276e864961c40bb49ff9981c58a9ee715","0cbca9f45a5508158a2415c9e3558b04b36aae5627e5700df5cd55282f710236","0cbca9f45a5508158a2415c9e3558b04b36aae5627e5700df5cd55282f710236","c19b12b36825a23078fe0ccd2e68b53aeaa0e7b8d02289b3858c5d7714b0d3ff","c19b12b36825a23078fe0ccd2e68b53aeaa0e7b8d02289b3858c5d7714b0d3ff","15f2ffd24f9af40b60ec3f71f3ead010fea7969249e143b47edb8b30792f4ff9","15f2ffd24f9af40b60ec3f71f3ead010fea7969249e143b47edb8b30792f4ff9","ba124dc0df0b01e420b3caadc7c6c30c27d8c3cc5add5d64676b735b41c91990","ba124dc0df0b01e420b3caadc7c6c30c27d8c3cc5add5d64676b735b41c91990","c283884b89995eeef789e08da2e4a8db2fd2318a20c8e2f37557addd91c5b36e","c283884b89995eeef789e08da2e4a8db2fd2318a20c8e2f37557addd91c5b36e","e7bb5ed3bc7f6c3a93c8b3386d3863c379478c90915647eea42598d042a61b84","e7bb5ed3bc7f6c3a93c8b3386d3863c379478c90915647eea42598d042a61b84","526dfec31d381fd74c284c294bf2697128c12735eb97fa1c1af390c2e50d9719","526dfec31d381fd74c284c294bf2697128c12735eb97fa1c1af390c2e50d9719"],"raw_response_sha256":["691d38cf709d885687ed2c936f297a856a0d077ebf235778e04c25bef6fe27f8","c5841e5b1d3e4aa5c0180c14bdfff83319e1cc8f63fa537d62695de01b6c17d8","7d191417d2c8b8f1857db938034d78ce202df87405263c9e4a4aa30dfb9bb54e","a1d1fe2864febf49f6bea3bb77a3facf1e3d49f204fe72e04d3b7c41996d2b05","652c4df0b30496e0c2d994dbe8f047e82d6ed1187408b53a33a041bd8149212c","652c4df0b30496e0c2d994dbe8f047e82d6ed1187408b53a33a041bd8149212c","dc5fe700daffa5ea6f6aa1839e51948d0d345d4ed9e911cd1e8d3da89fa9973e","32dd198a87b1eeae7e4d11a26c5719384605d053d6b336b31752da4f8f37fa37","54dc36fb5f0e22e05a47d70260eeb67828cb0d7eef5754eb5603ba11b2326f25","54dc36fb5f0e22e05a47d70260eeb67828cb0d7eef5754eb5603ba11b2326f25","bfdb131f98cfc7275009825a5dbd99fe44a6f3a194461b279783dedb82f28328","bfdb131f98cfc7275009825a5dbd99fe44a6f3a194461b279783dedb82f28328","03c21391b6bd8cb64e98934f54b2b33e3086087cc55201b7b5f54e4f0ed46161","03c21391b6bd8cb64e98934f54b2b33e3086087cc55201b7b5f54e4f0ed46161","ef00a84a2b131e7af042f7ee5f371c17779fba26fa5d99dab75d3eb510e253cd","a88c5a2323a3a04395c6ba335888f078d6a95ca3b50d387e31f74257d3ca3cf2","c605f9430199ada0855070d22d69df6726abc186c6513a6f5198f9ccea1e90af","c605f9430199ada0855070d22d69df6726abc186c6513a6f5198f9ccea1e90af","d680308a5be983809966000ab908cc55322e215c7c45c668019b14d7be0ffabf","d680308a5be983809966000ab908cc55322e215c7c45c668019b14d7be0ffabf","674ae4706b8f07dc74b52d82d9842bdc8dbcb6742b7909da8a3e279230364dac","674ae4706b8f07dc74b52d82d9842bdc8dbcb6742b7909da8a3e279230364dac","649d55d3f385a23f348fdd26fce7cd8241b4a5312329f4583a1dd0c7527a62ab","24ff28e90eb678653264f6c1baa8480a0c4204c1d826fb6c88252fc382c752c8"],"run_ids":["ANC-007-plan-v4__approved-pass__r1","ANC-007-plan-v4__approved-pass__r2","ANC-007-plan-v4__approved-fail__r1","ANC-007-plan-v4__approved-fail__r2","ANC-007-plan-v4__minimal-compliant__r1","ANC-007-plan-v4__minimal-compliant__r2","ANC-007-plan-v4__silent__r1","ANC-007-plan-v4__silent__r2","ANC-007-plan-v4__topical__r1","ANC-007-plan-v4__topical__r2","ANC-007-plan-v4__direct-conflict__r1","ANC-007-plan-v4__direct-conflict__r2","ANC-007-plan-v4__irrelevant__r1","ANC-007-plan-v4__irrelevant__r2","ANC-007-plan-v4__boundary__r1","ANC-007-plan-v4__boundary__r2","ANC-007-plan-v4__nonboundary-compliant__r1","ANC-007-plan-v4__nonboundary-compliant__r2","ANC-007-plan-v4__nonboundary-conflict__r1","ANC-007-plan-v4__nonboundary-conflict__r2","ANC-007-plan-v4__ordinary-config-allowed__r1","ANC-007-plan-v4__ordinary-config-allowed__r2","ANC-007-plan-v4__optional-atm-config-allowed__r1","ANC-007-plan-v4__optional-atm-config-allowed__r2"]},"oracle":{"case_count":12,"case_ids":["approved-pass","approved-fail","minimal-compliant","silent","topical","direct-conflict","irrelevant","boundary","nonboundary-compliant","nonboundary-conflict","ordinary-config-allowed","optional-atm-config-allowed"],"repeat_count":2,"sha256":"483161cef4ebd4de1ea72400722e922bb2deb4d88989eba9ebf0f8236b8129d9"},"previous_event_sha256":null,"protocol_version":"plan-anchor/question-tournament/2.0.0","score":{"confidence":{"cells_at_or_above_threshold":34,"mean":0.9519,"median":1.0,"minimum":0.52,"p10":0.86,"threshold":0.8,"total_cells":36},"exact_role_cells":36,"exact_semantic_verdicts":12,"regressions":0,"stable_cases":12,"total_cases":12,"total_role_cells":36,"total_semantic_verdicts":12},"supersedes":{"decision_sha256":"c50cdeb7075e4a143b58d069f2405079cee507b2911d83ccda24290b4e52ad6d","protocol_version":"initial-empty-history"}}],"history_id":"ANC-007-plan","schema":"plan-anchor/tuning-history/2"}
```
