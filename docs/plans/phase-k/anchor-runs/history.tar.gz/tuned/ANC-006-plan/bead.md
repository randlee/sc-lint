# ANC-006 plan questions

Accepted independent tuning; question digest 48ba33d2ea5a634e6e246c7926a3160f445e4e62893209cc104bafb164ed18f2.

```json
{
  "questions": {
    "relevant": {
      "type": "choice",
      "instructions": "Compare the work with the approved anchor scope. Does `item.text` touch optional consumer policies, including manifests, allowlists, configuration tables, and other supported forms? Omission or noncompliance remains relevant. Assess subject applicability only.",
      "criteria": {
        "yes": "The work touches optional consumer policies, including manifests, allowlists, configuration tables, and other supported forms, including investigations and incomplete changes.",
        "no": "The work is unrelated or explicitly says no optional consumer policy mechanism is introduced or changed.",
        "unclear": "The text does not establish whether this subject is touched."
      }
    },
    "addressed": {
      "type": "choice",
      "instructions": "Compare the work with the approved anchor scope. Does `item.text` explicitly commit to behavior satisfying: supplied optional policy is enforced AND absence preserves that policy\u2019s prior result on identical input; both branches are necessary? Judge specific compliance only.",
      "criteria": {
        "yes": "supplied optional policy is enforced AND absence preserves that policy\u2019s prior result on identical input; both branches are necessary. Equivalent substantive wording counts.",
        "no": "The behavior is absent, merely topical, incomplete, or replaced by an incompatible alternative.",
        "unclear": "The text alludes to the specific behavior but its meaning is unresolved."
      }
    },
    "contradicted": {
      "type": "choice",
      "instructions": "Compare the work with the approved anchor scope. Does `item.text` explicitly choose behavior that conflicts because a supplied optional policy is ignored OR absence changes that policy\u2019s prior result solely due to the new optional mechanism? Omission, investigation, and topical mention alone do not conflict.",
      "criteria": {
        "yes": "a supplied optional policy is ignored OR absence changes that policy\u2019s prior result solely due to the new optional mechanism.",
        "no": "No incompatible behavior is stated; silence and missing detail alone count no.",
        "unclear": "Stated behavior might be incompatible but cannot be resolved."
      }
    }
  }
}
```

Canonical tuning history SHA-256: 7657364da06749cc74a85d16670004af03dbfcffd08ffd401483a70666d5245d

```tuning-history
{"events":[{"authority":{"anchor_id":"ANC-006","anchor_record_sha256":"3c31fb923e588908d72fe8b7b453109ee6b688e1a30903116fa1ff8628cc0e86","anchor_version":3,"intent_id":"phase-k-intent","intent_sha256":"076f46ac1fba20eb8a57b51159e3f8128571dd3186053103daf4b5494813d2c3","intent_version":3},"candidate":{"candidate_id":"v2","question_sha256":"48ba33d2ea5a634e6e246c7926a3160f445e4e62893209cc104bafb164ed18f2"},"decision":{"question_set_sha256":"48ba33d2ea5a634e6e246c7926a3160f445e4e62893209cc104bafb164ed18f2","reason_code":"TOURNAMENT.ACCEPTED","status":"sealed"},"event":"question_set_sealed","event_index":1,"evidence":{"canonical_request_sha256":["78bdfa08a21c7974216d501fbad9f93ed011317cf274870369ad3fbbc14b6a51","78bdfa08a21c7974216d501fbad9f93ed011317cf274870369ad3fbbc14b6a51","90e68b8607ccf8ec7cc92004c597143ab99b8aba2d7203cbabdf8adcd46b54ba","90e68b8607ccf8ec7cc92004c597143ab99b8aba2d7203cbabdf8adcd46b54ba","84fe05db6c6c1cb703721b8486515b0820c69a1a2161197ba133b6cde46db30a","84fe05db6c6c1cb703721b8486515b0820c69a1a2161197ba133b6cde46db30a","de18d8963b88a6454744bc98cc1fb16921edc6a2b577b1557b919780db7f9269","de18d8963b88a6454744bc98cc1fb16921edc6a2b577b1557b919780db7f9269","5bd2a42a1dc200e0107feff3754f1ee38b574f3ec8acebc9be1e896a4df4c836","5bd2a42a1dc200e0107feff3754f1ee38b574f3ec8acebc9be1e896a4df4c836","fe6d027de5556bd120fab9713d485c6724e1ac55a8a7638b7b99e48f2db9db3b","fe6d027de5556bd120fab9713d485c6724e1ac55a8a7638b7b99e48f2db9db3b","a94dd7a6a58dd2e4d820c932119e41db2b4d03edda3ae23208ca74a2cf10c65c","a94dd7a6a58dd2e4d820c932119e41db2b4d03edda3ae23208ca74a2cf10c65c","43dd66456200d5fb74f4dc1fd73ee07d2676f81417fb4303611be127ed7d034e","43dd66456200d5fb74f4dc1fd73ee07d2676f81417fb4303611be127ed7d034e","14e8b55da496346e09494dead24f6df401a016a04662676ffa19d57ab05b01b1","14e8b55da496346e09494dead24f6df401a016a04662676ffa19d57ab05b01b1","a9710ae02cc5b110bbe185b63abe37844d7cbd5ba12f945a7951cd5effbcaac3","a9710ae02cc5b110bbe185b63abe37844d7cbd5ba12f945a7951cd5effbcaac3","5c2a88c750fe2bdc64de8f7183fe8482232c0cd015eb0ab46f45181e5aece400","5c2a88c750fe2bdc64de8f7183fe8482232c0cd015eb0ab46f45181e5aece400","df96212f7b2eb8b27733af77b3660c38e53f2cb560d2e67f94ca0e37f58b0dc6","df96212f7b2eb8b27733af77b3660c38e53f2cb560d2e67f94ca0e37f58b0dc6"],"raw_response_sha256":["4298664a04878bb9afeae81f6a3e0b29789ae8d7c794cbb51aea46115114cc99","4298664a04878bb9afeae81f6a3e0b29789ae8d7c794cbb51aea46115114cc99","1d7327b6e690c5411b5753ca046a7722738f5ec83f04e1c7dcaa84c4cbeda2d9","1d7327b6e690c5411b5753ca046a7722738f5ec83f04e1c7dcaa84c4cbeda2d9","cdcf57364d4779d37a0020abaf9c5bb718e56f88a3d5105d437c9139b36e642e","cdcf57364d4779d37a0020abaf9c5bb718e56f88a3d5105d437c9139b36e642e","08bdd12b99995b13c2089cc3a1d4de291b17b111188b6ba3317351087ffcfca7","08bdd12b99995b13c2089cc3a1d4de291b17b111188b6ba3317351087ffcfca7","08bdd12b99995b13c2089cc3a1d4de291b17b111188b6ba3317351087ffcfca7","08bdd12b99995b13c2089cc3a1d4de291b17b111188b6ba3317351087ffcfca7","8b4a1bf5d06b843668ffe3a1611c997465555c362de488bd9f83f08fda272989","8b4a1bf5d06b843668ffe3a1611c997465555c362de488bd9f83f08fda272989","06f5415e7bdbd1c48cab0edb70478c7aae7ae5409af045757c47f738bae92b89","06f5415e7bdbd1c48cab0edb70478c7aae7ae5409af045757c47f738bae92b89","4211b3b9ec7d4466793b85464fe40c8ada20a24be06194adf44764a33c5391e9","4211b3b9ec7d4466793b85464fe40c8ada20a24be06194adf44764a33c5391e9","5c93d7af1048f6bf688b51e0d8bcc4a9e85c2a37b1342b2d0d87cd196c10d770","92703c08973523ef48866414c65d9d74be09adfebd4fdc52b79bf1a7410087d4","b83c0c6ad9640c7860a92023cb00f990bf0bbee94951995669ec2d2b8a54566e","b83c0c6ad9640c7860a92023cb00f990bf0bbee94951995669ec2d2b8a54566e","89c530fdd3dbd4d6c2f181606826f1a13ee04f77cf73cd860c720a438f6caff1","90ebfbd82439c293eaaed5e4f4fe28f3edada6d2ad7b83d79db2987e62f06cfd","8a0b4273f3c1cb0ff3bd5a7cd17d0b3f0f5b0d6f72f242e441189072001695c9","01178ff19fcb763602dc46dc448efcd3cb586409298c001c70c0d3987b452c00"],"run_ids":["ANC-006-plan-v2__approved-pass__r1","ANC-006-plan-v2__approved-pass__r2","ANC-006-plan-v2__approved-fail__r1","ANC-006-plan-v2__approved-fail__r2","ANC-006-plan-v2__paraphrase__r1","ANC-006-plan-v2__paraphrase__r2","ANC-006-plan-v2__silent__r1","ANC-006-plan-v2__silent__r2","ANC-006-plan-v2__topical__r1","ANC-006-plan-v2__topical__r2","ANC-006-plan-v2__direct-conflict__r1","ANC-006-plan-v2__direct-conflict__r2","ANC-006-plan-v2__irrelevant__r1","ANC-006-plan-v2__irrelevant__r2","ANC-006-plan-v2__boundary__r1","ANC-006-plan-v2__boundary__r2","ANC-006-plan-v2__nonfixture-manifest__r1","ANC-006-plan-v2__nonfixture-manifest__r2","ANC-006-plan-v2__supplied-ignored__r1","ANC-006-plan-v2__supplied-ignored__r2","ANC-006-plan-v2__absence-only__r1","ANC-006-plan-v2__absence-only__r2","ANC-006-plan-v2__presence-only__r1","ANC-006-plan-v2__presence-only__r2"]},"oracle":{"case_count":12,"case_ids":["approved-pass","approved-fail","paraphrase","silent","topical","direct-conflict","irrelevant","boundary","nonfixture-manifest","supplied-ignored","absence-only","presence-only"],"repeat_count":2,"sha256":"b9946297f14a118304b977c3f6922d7e4ca26d99b8d8d8c31c50c16072b10631"},"previous_event_sha256":null,"protocol_version":"plan-anchor/question-tournament/2.0.0","score":{"confidence":{"cells_at_or_above_threshold":36,"mean":0.99,"median":1.0,"minimum":0.91,"p10":0.97,"threshold":0.8,"total_cells":36},"exact_role_cells":36,"exact_semantic_verdicts":12,"regressions":0,"stable_cases":12,"total_cases":12,"total_role_cells":36,"total_semantic_verdicts":12},"supersedes":{"decision_sha256":"6dd68499db703e0bcd557fea34b73efdb5f449416248ea0c63c26d5297040672","protocol_version":"initial-empty-history"}}],"history_id":"ANC-006-plan","schema":"plan-anchor/tuning-history/2"}
```
