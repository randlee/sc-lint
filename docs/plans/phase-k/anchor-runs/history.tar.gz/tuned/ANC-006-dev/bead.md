# ANC-006 dev questions

Accepted independent tuning; question digest 3ec38f07e4a1c90e831bdb96ada4bcfce0adf47f5954a567df49e3f1f4929c7f.

```json
{
  "questions": {
    "relevant": {
      "type": "choice",
      "instructions": "Use the specific behavioral distinction in the criteria to judge `item.text`; do not infer missing behavior. Is the governed work present? Investigating it or omitting its constraint still touches its subject.",
      "criteria": {
        "yes": "Classify yes when the work touches optional consumer policies, including manifests, allowlists, configuration tables, and other supported forms, including investigations and incomplete changes.",
        "no": "Classify no when the work is unrelated or explicitly says no optional consumer policy mechanism is introduced or changed.",
        "unclear": "Classify unclear when the text does not establish whether this subject is touched."
      }
    },
    "implemented": {
      "type": "choice",
      "instructions": "Use the specific behavioral distinction in the criteria to judge `item.text`; do not infer missing behavior. Does the described result implement the complete obligation, including every conditional branch? Evidence presence is separate.",
      "criteria": {
        "yes": "Classify yes when supplied optional policy is enforced AND absence preserves that policy\u2019s prior result on identical input; both branches are necessary. Equivalent substantive wording counts.",
        "no": "Classify no when the behavior is absent, merely topical, incomplete, or replaced by an incompatible alternative.",
        "unclear": "Classify unclear when the text alludes to the specific behavior but its meaning is unresolved."
      }
    },
    "violated": {
      "type": "choice",
      "instructions": "Use the specific behavioral distinction in the criteria to judge `item.text`; do not infer missing behavior. Does the described result affirmatively break the obligation? Silence alone says no.",
      "criteria": {
        "yes": "Classify yes when a supplied optional policy is ignored OR absence changes that policy\u2019s prior result solely due to the new optional mechanism.",
        "no": "Classify no when no incompatible behavior is stated; silence and missing detail alone count no.",
        "unclear": "Classify unclear when stated behavior might be incompatible but cannot be resolved."
      }
    },
    "evidenced": {
      "type": "choice",
      "instructions": "Use the specific behavioral distinction in the criteria to judge `item.text`; do not infer missing behavior. Are concrete artifacts or observed checks supplied for the governed behavior? Evidence may demonstrate failure as well as success.",
      "criteria": {
        "yes": "Classify yes when an inspectable code or diff excerpt, specific artifact content, or a concrete command/test observation substantiates the rule behavior.",
        "no": "Classify no when only assertions, intentions, topic mentions, or unsubstantiated claims are supplied; no concrete behavioral evidence.",
        "unclear": "Classify unclear when a cited artifact cannot be connected to the relevant behavior."
      }
    }
  }
}
```

Canonical tuning history SHA-256: f9c5496ca7001f56e401bfc7a6aca49e9e2b46b0e6c2eb7cd5110819971811e0

```tuning-history
{"events":[{"authority":{"anchor_id":"ANC-006","anchor_record_sha256":"3c31fb923e588908d72fe8b7b453109ee6b688e1a30903116fa1ff8628cc0e86","anchor_version":3,"intent_id":"phase-k-intent","intent_sha256":"076f46ac1fba20eb8a57b51159e3f8128571dd3186053103daf4b5494813d2c3","intent_version":3},"candidate":{"candidate_id":"v4","question_sha256":"3ec38f07e4a1c90e831bdb96ada4bcfce0adf47f5954a567df49e3f1f4929c7f"},"decision":{"question_set_sha256":"3ec38f07e4a1c90e831bdb96ada4bcfce0adf47f5954a567df49e3f1f4929c7f","reason_code":"TOURNAMENT.ACCEPTED","status":"sealed"},"event":"question_set_sealed","event_index":1,"evidence":{"canonical_request_sha256":["4c32374d7097130ec6f1f83d662bdd2231cdb5dce051ecee22d87d78f277ae40","4c32374d7097130ec6f1f83d662bdd2231cdb5dce051ecee22d87d78f277ae40","a1436e8368c848c3528e16dce418dc5d43893945713f3a454f770e90571bc1ff","a1436e8368c848c3528e16dce418dc5d43893945713f3a454f770e90571bc1ff","246baad5747a8e006545a05920410e9de1106891378ce09d148b131f51eb0bea","246baad5747a8e006545a05920410e9de1106891378ce09d148b131f51eb0bea","754510734154069be49d02409e82953f337a105c63e4f15585a70cb08f8219ed","754510734154069be49d02409e82953f337a105c63e4f15585a70cb08f8219ed","6066d9bd7969c8a618d2a21fb8ae0ba589e4b2ebc236266a7a44b10306258999","6066d9bd7969c8a618d2a21fb8ae0ba589e4b2ebc236266a7a44b10306258999","3f7dd72362be91b849f3977fad0b063027208f5d487be04f426e50fa0cdcf7ec","3f7dd72362be91b849f3977fad0b063027208f5d487be04f426e50fa0cdcf7ec","6d4bdb8e564a5b243be9b6cbdffaff8ea77542f9a55600cb59ff7289932c6554","6d4bdb8e564a5b243be9b6cbdffaff8ea77542f9a55600cb59ff7289932c6554","dce5291359ce5521f81489bda09f05bfbf2938bacca364a4a493540acafccbd0","dce5291359ce5521f81489bda09f05bfbf2938bacca364a4a493540acafccbd0","d9404cd959b9a58e6c575b03723ff54b979dabb86690fef5287e6cc06fc9ff92","d9404cd959b9a58e6c575b03723ff54b979dabb86690fef5287e6cc06fc9ff92","ba983f9457ddcea8e947e00c2cb0a451b007e41c9d6b04dbdff287804ca9fc53","ba983f9457ddcea8e947e00c2cb0a451b007e41c9d6b04dbdff287804ca9fc53","1457de6595b4746fc26bc17d5deb986591da9266a5deb574cf7c15df855465cc","1457de6595b4746fc26bc17d5deb986591da9266a5deb574cf7c15df855465cc","048c098b8b148355156c35bde7e9b3b3324d02e1a07bec439ad1c3442418334c","048c098b8b148355156c35bde7e9b3b3324d02e1a07bec439ad1c3442418334c","029f5752543c44d375e482f9d51384b986d6f68f048662cc4572412b4e9acd9d","029f5752543c44d375e482f9d51384b986d6f68f048662cc4572412b4e9acd9d","ae4619b213407e1a801d41009bf1ed24a867a5dd5a3a7a091f3ece18506fa243","ae4619b213407e1a801d41009bf1ed24a867a5dd5a3a7a091f3ece18506fa243"],"raw_response_sha256":["f9ec7fb6f9d78e16252823295f4f00a84c6fbf60c0ca5f1b4a2f7937aaa44e17","619caa6a6182076301593881037fccb6020255afeef5999c6c82fab0bfe3a194","6afb6bc319cc8249c5b8ba9ad761bd7c5cae97b1f226ac19baa1444e8c5c37fa","ebd0f8f8ce6025bd501c73f29e1355f125789d83f7de072f2f54a1a3864a1c37","25edd2728051353fa80ebfb77f4612cf47772abc96e37dbc4e15561005c8174f","b34cc9810ba3831677836a9660989d5ba1e86b8d921434e7a6efa9dad85d1d2d","5a4e0cfb9427ccab44a8578b5b70bf1fb6fd5c3f46742993def822733772bda4","f105a51153c593e259e6479fa69f2c705a741ebbe5fe6e6c1611dca08b248610","b146fe52deff25222083b05cbc0a2eb7883adb38b611778c5128d201b833c629","b146fe52deff25222083b05cbc0a2eb7883adb38b611778c5128d201b833c629","1333b4edcfe0d00caf0a28c2d2aefbde4ed4ccdc8a7915a6684e11cc3c6e7719","1333b4edcfe0d00caf0a28c2d2aefbde4ed4ccdc8a7915a6684e11cc3c6e7719","62d386d5e62eff2dd3ce73cc774a7b445173eee312a99f8e1ea6709618fd2454","338ce8fe274a549d803e0b4e3a6b7cf5812c9c9cff8e2e4757a0662e7fba2b45","ddcf1aca5afd1377cc59ecadfb4b2f3fe4a07f3b81a89000784f2864e88ea87d","38c718bb766ccbfeff345c1238ac61a0a9b3ef9a86218ee052a8153887787e01","8d8d79303b927d2927627520ee6c52fafc213e7cc15da23a253274041dd9d3f5","90e5c578b863540a7ca2b38e2ec19fb4953911a4c5d94fdea80f75fece1c0150","5bb658e21cfe35c5c473ecd2fc430f15c04fea106332b00431407dcb65e764bc","07d2b905cff45953fb0c7c69d209d97575b2b1acaf2f6b3bc312688cac4713b2","43cce11bb91acef7454d14ab07d5c3efbd93400cbbc9077afc835ae573d7355b","73ce6f3bff2c5d5f00b8f19a8d5c7af690d5d2541b2f7a7463644eee430b0378","a7fcb049139baf70e22cd77dd5212eda5c9c89c734c882cce1225d12634ecba8","1e4c6ccf037bdeace7b985bce1d6d9ecddb28d7df6c400c596d7e50f8d19f717","560e55b2de41db3f571ca7ad9ccc09444301bb9bd4546cf631aab72b3cd7d5f5","864a98ad2f5f4a3e9d98efdb1ab8e71446555d18fddf357fd576e3c01ddd927e","4df4466fe7cf1b406001a7e123cc8a974325e451f93daa8a35df91bd544cca34","b4ec1ce17c8a41c26daa285e1c8a01b2c060d18a3a620abe96d366296f31b4f3"],"run_ids":["ANC-006-dev-v4__approved-pass__r1","ANC-006-dev-v4__approved-pass__r2","ANC-006-dev-v4__approved-fail__r1","ANC-006-dev-v4__approved-fail__r2","ANC-006-dev-v4__paraphrase__r1","ANC-006-dev-v4__paraphrase__r2","ANC-006-dev-v4__silent__r1","ANC-006-dev-v4__silent__r2","ANC-006-dev-v4__topical__r1","ANC-006-dev-v4__topical__r2","ANC-006-dev-v4__direct-conflict__r1","ANC-006-dev-v4__direct-conflict__r2","ANC-006-dev-v4__irrelevant__r1","ANC-006-dev-v4__irrelevant__r2","ANC-006-dev-v4__boundary__r1","ANC-006-dev-v4__boundary__r2","ANC-006-dev-v4__nonfixture-manifest__r1","ANC-006-dev-v4__nonfixture-manifest__r2","ANC-006-dev-v4__supplied-ignored__r1","ANC-006-dev-v4__supplied-ignored__r2","ANC-006-dev-v4__absence-only__r1","ANC-006-dev-v4__absence-only__r2","ANC-006-dev-v4__presence-only__r1","ANC-006-dev-v4__presence-only__r2","ANC-006-dev-v4__concrete-evidence__r1","ANC-006-dev-v4__concrete-evidence__r2","ANC-006-dev-v4__evidenced-conflict__r1","ANC-006-dev-v4__evidenced-conflict__r2"]},"oracle":{"case_count":14,"case_ids":["approved-pass","approved-fail","paraphrase","silent","topical","direct-conflict","irrelevant","boundary","nonfixture-manifest","supplied-ignored","absence-only","presence-only","concrete-evidence","evidenced-conflict"],"repeat_count":2,"sha256":"1b64a2122a57043452621b745316b82828970af3792326c95e94eac9371e177a"},"previous_event_sha256":null,"protocol_version":"plan-anchor/question-tournament/2.0.0","score":{"confidence":{"cells_at_or_above_threshold":54,"mean":0.9602,"median":1.0,"minimum":0.4,"p10":0.89,"threshold":0.8,"total_cells":56},"exact_role_cells":56,"exact_semantic_verdicts":14,"regressions":0,"stable_cases":14,"total_cases":14,"total_role_cells":56,"total_semantic_verdicts":14},"supersedes":{"decision_sha256":"acfd3bba580d80b1472644fb799772a21f36cb54772dc95791c1a60d54a732fa","protocol_version":"initial-empty-history"}}],"history_id":"ANC-006-dev","schema":"plan-anchor/tuning-history/2"}
```
