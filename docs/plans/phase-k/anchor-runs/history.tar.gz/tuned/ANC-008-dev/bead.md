# ANC-008 dev questions

Accepted independent tuning; question digest f0322ecc1b5d48b02d37b86d9eda7a3b842aec03f21206962b8368cb7bb5f728.

```json
{
  "questions": {
    "relevant": {
      "type": "choice",
      "instructions": "Judge only whether `item.text` touches a Phase K sprint that fixes a reported consumer gap. Omission or conflict remains relevant. Work explicitly outside the governing subject is not relevant.",
      "criteria": {
        "yes": "It changes, investigates, or defines a Phase K sprint that fixes a reported consumer gap.",
        "no": "It is unrelated, or explicitly establishes that the item is not a sprint fixing a reported consumer gap.",
        "unclear": "The governed subject cannot be determined."
      }
    },
    "implemented": {
      "type": "choice",
      "instructions": "Does the delivered account state it actually did cite the reporting GitHub issue and include an issue-linked regression test reproducing its reported failure? Judge the specific obligation in `item.text`, not topic mention or conflict. Future intentions are not completed behavior; evidence is judged separately.",
      "criteria": {
        "yes": "The text explicitly states cite the reporting GitHub issue and include an issue-linked regression test reproducing its reported failure as completed behavior.",
        "no": "The obligation is omitted, only its topic is mentioned, or an incompatible approach replaces it. A plan to do it later also counts no.",
        "unclear": "The text alludes to compliance but leaves the required behavior uncertain."
      }
    },
    "violated": {
      "type": "choice",
      "instructions": "Does `item.text` report a completed Phase K gap-fix sprint that explicitly rejected or deferred its issue-linked regression reproduction? Judge incompatible choices only. Missing discussion alone is not violation.",
      "criteria": {
        "yes": "The completed sprint deliberately omitted the reporting GitHub issue link, skipped or deferred reproduction of the reported consumer failure beyond the sprint, or substituted only a generic success test.",
        "no": "No incompatible completed decision is reported; absent issue or test discussion is silence.",
        "unclear": "Whether the delivered sprint rejected the required issue-linked failure reproduction cannot be determined."
      }
    },
    "evidenced": {
      "type": "choice",
      "instructions": "Does `item.text` cite a checkable artifact that directly supports completed delivery of an issue-linked regression reproducing the reported consumer failure? A bare assertion that a test exists, even with an issue number and described input, is not an artifact citation. Require a test name/path, code/diff reference, command/output, or before/after observation tied to that regression. Judge evidence only.",
      "criteria": {
        "yes": "It gives a concrete locator, test name, code/diff reference, executed command/output, or before/after observation directly supporting the issue-linked failure reproduction.",
        "no": "It merely asserts a regression test exists or describes what it covers without citing a checkable artifact; no compliance claim is made; or only unrelated evidence is cited.",
        "unclear": "A possible artifact citation is present but its connection to the issue-linked failure reproduction is uncertain."
      }
    }
  }
}
```

Canonical tuning history SHA-256: db77ff07a74d2234e280e08770dbe593f0fa240f1c23f13ad903b9f71f91ef54

```tuning-history
{"events":[{"authority":{"anchor_id":"ANC-008","anchor_record_sha256":"d66efb6955562ea15f9f333cb6c490fe58be541143bfd2f46181e6b701c04c30","anchor_version":3,"intent_id":"phase-k-intent","intent_sha256":"076f46ac1fba20eb8a57b51159e3f8128571dd3186053103daf4b5494813d2c3","intent_version":3},"candidate":{"candidate_id":"v4","question_sha256":"f0322ecc1b5d48b02d37b86d9eda7a3b842aec03f21206962b8368cb7bb5f728"},"decision":{"question_set_sha256":"f0322ecc1b5d48b02d37b86d9eda7a3b842aec03f21206962b8368cb7bb5f728","reason_code":"TOURNAMENT.ACCEPTED","status":"sealed"},"event":"question_set_sealed","event_index":1,"evidence":{"canonical_request_sha256":["7dfd98c72cb269d5adc274b9066d176ba40f7384a3bd8b371cccf5e5704e9d0c","7dfd98c72cb269d5adc274b9066d176ba40f7384a3bd8b371cccf5e5704e9d0c","250b5fcb4015312500412eceaae6e646a956d995d2cb35593ddf7af76387489c","250b5fcb4015312500412eceaae6e646a956d995d2cb35593ddf7af76387489c","e21220e1ef0d7cf41f5864da281cb39216bad0ef30380ed5d965a2c96aca0e44","e21220e1ef0d7cf41f5864da281cb39216bad0ef30380ed5d965a2c96aca0e44","cc6557532dd57799175e5174ea57677f9ed96f92339e21c124cebcf5b838af5b","cc6557532dd57799175e5174ea57677f9ed96f92339e21c124cebcf5b838af5b","8f344e6a070667f5be1af4d5de8de44ad5e3bfba03c30b8cb670388706440adc","8f344e6a070667f5be1af4d5de8de44ad5e3bfba03c30b8cb670388706440adc","a4b6fa36b06dd4d7da31576e83ef8739c62ace3d1cb254009501312dc4a10a60","a4b6fa36b06dd4d7da31576e83ef8739c62ace3d1cb254009501312dc4a10a60","2bff7d897d40142847174149e5d0f074f66e4f283e18d6929296dabc85d1a358","2bff7d897d40142847174149e5d0f074f66e4f283e18d6929296dabc85d1a358","ac26df9849ead22f536d1bc314bd8e9e5e7d90d1b5e1a576571960d5e43aaa2f","ac26df9849ead22f536d1bc314bd8e9e5e7d90d1b5e1a576571960d5e43aaa2f","4b7c7524426105188cd9dd88a2a341da9744b66af1f92c9959bbaef6fa6eb90c","4b7c7524426105188cd9dd88a2a341da9744b66af1f92c9959bbaef6fa6eb90c","839121e7f66cd333eae01f38050a7260bda478f3175a7c92a2de97aa5e55e676","839121e7f66cd333eae01f38050a7260bda478f3175a7c92a2de97aa5e55e676","a5a013145c081b46abb5baf89024d0b5a21d4cdbaa77d3c0120fafc9bea87b1f","a5a013145c081b46abb5baf89024d0b5a21d4cdbaa77d3c0120fafc9bea87b1f","6fc0579b4422951814128e24be9aeb8c505c593833e36fa9000e239338475e0d","6fc0579b4422951814128e24be9aeb8c505c593833e36fa9000e239338475e0d","d1aee21a9d8f67a9fd4800712a20aa71f197ece9816768a2962a8c928dd94517","d1aee21a9d8f67a9fd4800712a20aa71f197ece9816768a2962a8c928dd94517","3a317bc1f26a896f27531bb109c4628cc67c076e6631515c0c4c92e48542bff7","3a317bc1f26a896f27531bb109c4628cc67c076e6631515c0c4c92e48542bff7","b34ea3011acd451c7481644f2e73c96be443acaa84b328faaf0887052b3b2b9c","b34ea3011acd451c7481644f2e73c96be443acaa84b328faaf0887052b3b2b9c"],"raw_response_sha256":["fbfb749283721993968371a9b19862ff51adc80c7e761810ec28900415f081c0","09cdcfbd2a01f9426e4feb48b4560208324c237943b3d21abf7c936758cfc4ea","0e2dfb658a2f0fe418b5309f55ae2af4f905f946c442af9867ae0f18f172ce10","ed568bb0ef7c2f14f78196b32252a9768dcdd97170a3d97dbea4e40c05e25a2a","815ff0e3d753a7a504c461e6781be2651be3f54e60a982b6b275c72f5825e8e3","944c9ae6e6a51e8535d1542046485e078262e6e3514f5ec2392b00666258346c","b1552538c508e82ad5a905739c4f87dc9df98dcb1971fcdc550b5366fd742039","b1552538c508e82ad5a905739c4f87dc9df98dcb1971fcdc550b5366fd742039","016ca80d2a8132f752cff599929757948a5adc1e5252fa713c5a31201216588c","551603ebd7d599baf4120fc968e6870868e1cfd029849963131a2e570d5d075a","51fdb9613d28f7f05b6c3ac63494b6b774572fc546270287b97f43854e32d31f","51fdb9613d28f7f05b6c3ac63494b6b774572fc546270287b97f43854e32d31f","8d4b1336a1c7a0bb0c53b03ccdc28d9f948fc56498669a54fe4d504c71fc704a","8d4b1336a1c7a0bb0c53b03ccdc28d9f948fc56498669a54fe4d504c71fc704a","fc40516d7f4be77f2327d38658f194b221864f5502ff9ac0b2a1fa7b481cd0c6","fc40516d7f4be77f2327d38658f194b221864f5502ff9ac0b2a1fa7b481cd0c6","ead3f55b904ac38f8a68cc4e54de5ad4dd960b7a9e5541b75368b2e7dc42b1e7","ead3f55b904ac38f8a68cc4e54de5ad4dd960b7a9e5541b75368b2e7dc42b1e7","03eeb2b54d9b82dcbe7f7b0595c465a6cd4b3f6d9e5f273387d54b002ed0b130","043c340c07cb2f1378da8f608fb23a76ea9c3265e48713dc1260618b2dc02eca","765fd05f314016c19ab7bf0a32d00d544f9c9225f2901253467b7c11fa035d90","765fd05f314016c19ab7bf0a32d00d544f9c9225f2901253467b7c11fa035d90","df7275f8cc90fa27fc86819009f6de11217386c33055670e098da830d55fc8e6","df7275f8cc90fa27fc86819009f6de11217386c33055670e098da830d55fc8e6","ffa3ccb08a91d4b301c59ab0abfe30c5338b0360a7255c310ddb7a3c04221e95","ffa3ccb08a91d4b301c59ab0abfe30c5338b0360a7255c310ddb7a3c04221e95","6f697952117f56f56ee034ff3d43d263b0b6e907c93a2517b06f69bfffc70a12","53b618b350095fe66c4a577096e56d535b0c630af0c5ded98888048ee73d3f60","aaa718c0b534355e163a0a841830a36e323fc94165000400234deb3072bdb1cb","f8397976bf6be4ae8dd4b2b7b5ded7136c607a48145559babb74592934c8a535"],"run_ids":["ANC-008-dev-v4__approved-pass__r1","ANC-008-dev-v4__approved-pass__r2","ANC-008-dev-v4__approved-fail__r1","ANC-008-dev-v4__approved-fail__r2","ANC-008-dev-v4__minimal-compliant__r1","ANC-008-dev-v4__minimal-compliant__r2","ANC-008-dev-v4__silent__r1","ANC-008-dev-v4__silent__r2","ANC-008-dev-v4__topical__r1","ANC-008-dev-v4__topical__r2","ANC-008-dev-v4__direct-conflict__r1","ANC-008-dev-v4__direct-conflict__r2","ANC-008-dev-v4__irrelevant__r1","ANC-008-dev-v4__irrelevant__r2","ANC-008-dev-v4__boundary__r1","ANC-008-dev-v4__boundary__r2","ANC-008-dev-v4__boundary-gap-compliant__r1","ANC-008-dev-v4__boundary-gap-compliant__r2","ANC-008-dev-v4__missing-issue-link-conflict__r1","ANC-008-dev-v4__missing-issue-link-conflict__r2","ANC-008-dev-v4__partial-omission__r1","ANC-008-dev-v4__partial-omission__r2","ANC-008-dev-v4__future-reproduction__r1","ANC-008-dev-v4__future-reproduction__r2","ANC-008-dev-v4__concretely-evidenced__r1","ANC-008-dev-v4__concretely-evidenced__r2","ANC-008-dev-v4__future-only__r1","ANC-008-dev-v4__future-only__r2","ANC-008-dev-v4__unrelated-evidence__r1","ANC-008-dev-v4__unrelated-evidence__r2"]},"oracle":{"case_count":15,"case_ids":["approved-pass","approved-fail","minimal-compliant","silent","topical","direct-conflict","irrelevant","boundary","boundary-gap-compliant","missing-issue-link-conflict","partial-omission","future-reproduction","concretely-evidenced","future-only","unrelated-evidence"],"repeat_count":2,"sha256":"fbcd7c39ec1b11a382ac8c51225b20b8d7f2c0998fb30b4579a53cf233872acb"},"previous_event_sha256":null,"protocol_version":"plan-anchor/question-tournament/2.0.0","score":{"confidence":{"cells_at_or_above_threshold":56,"mean":0.9547,"median":1.0,"minimum":0.35,"p10":0.83,"threshold":0.8,"total_cells":60},"exact_role_cells":60,"exact_semantic_verdicts":15,"regressions":0,"stable_cases":15,"total_cases":15,"total_role_cells":60,"total_semantic_verdicts":15},"supersedes":{"decision_sha256":"eaeab381c9dad492f73b4fd59e340c948d0137eabbe57e484909aabb072e4074","protocol_version":"initial-empty-history"}}],"history_id":"ANC-008-dev","schema":"plan-anchor/tuning-history/2"}
```
