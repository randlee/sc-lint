import concurrent.futures,hashlib,importlib.util,json,os,pathlib,time
p=pathlib.Path('/tmp/phase-k-plan/review-round2/anc004-triage/tune')
req=json.loads((p/'request.json').read_text());oracle=json.loads((p/'oracle.json').read_text());pool=json.loads((p/'candidates.json').read_text())
assert req['correlation_id']==oracle['correlation_id'] and oracle['frozen_before_live'] and len(pool)>=req['candidate_minimum']
assert all(c['state']['anchor']['id']=='ANC-004' for c in oracle['cases'])
sp=importlib.util.spec_from_file_location('j',req['runtime']['script']);J=importlib.util.module_from_spec(sp);sp.loader.exec_module(J)
key=os.environ['TYPESAFE_API_KEY'].strip();J.check_api_key(key)
raw=p/'raw';raw.mkdir(exist_ok=True)
def send(job):
 v,c,r=job;fn=f"{v}__{c['case_id']}__r{r}";body={'model':'jev-latest','questions':pool[v],'state':c['state']};b=J.encode_body(body);sha=hashlib.sha256(b).hexdigest();(raw/(fn+'.request.json')).write_bytes(b)
 errors=[]
 for at in range(2):
  try:
   resp=J.call_jev(body,key,45.0);J.validate_response(resp,pool[v]);(raw/(fn+'.response.json')).write_text(json.dumps(resp,indent=2,ensure_ascii=False)+'\n')
   return {'candidate_id':v,'case_id':c['case_id'],'repeat':r,'request_sha256':sha,'response_sha256':hashlib.sha256(json.dumps(resp,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest(),'response':resp,'attempts':at+1,'errors':errors,'correlation_id':f"{req['correlation_id']}-{fn}"}
  except J.JudgeError as e:
   errors.append({'code':e.code,'message':str(e)})
   if not e.recoverable or at==1:return {'candidate_id':v,'case_id':c['case_id'],'repeat':r,'request_sha256':sha,'attempts':at+1,'errors':errors,'correlation_id':f"{req['correlation_id']}-{fn}"}
   time.sleep(1)
jobs=[(v,c,r) for v in ['v4'] for c in oracle['cases'] for r in (1,2)]
rows=[];out=p/'attempts-v4.json'
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for row in ex.map(send,jobs):
  rows.append(row);out.write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
by={(x['candidate_id'],x['case_id'],x['repeat']):x for x in rows};third=[]
for v in ['v4']:
 for c in oracle['cases']:
  a=by[v,c['case_id'],1];b=by[v,c['case_id'],2]
  if 'response' in a and 'response' in b and any(J.answer_choice(a['response']['answers'][role])[0]!=J.answer_choice(b['response']['answers'][role])[0] for role in pool[v]):third.append((v,c,3))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for row in ex.map(send,third):rows.append(row);out.write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
print('calls',len(rows),'third',len(third),'errors',sum('response' not in x for x in rows))
