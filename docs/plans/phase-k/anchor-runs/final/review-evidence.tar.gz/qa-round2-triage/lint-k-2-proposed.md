# Sprint k-2 — platform-adapter-boundaries

## Scope boundary
#372; effort 10–18h. ADR-010 as amended by ADR-017, REQ-PRODUCT-023 and ANC-001–009 govern. Existing simpler consumers continue to run sc-lint without atm-core-specific configuration; `platform_adapters` remains optional and is needed only to opt into paired-module behavior. The same behavior supports consumer repositories beyond atm-core; do not hard-code atm-core repository identities or private policy. Rust portability owns module validation and PORT-010 decisions; k1 supplies typed paths, own_tables, filtering and generated installer catalog.

## Authoritative deliverables
See Deliverables.

## Deliverables
1. Register `platform_adapters` in PORTABILITY_CATALOG.own_keys. Parse through k1 own_tables into private `PlatformAdapterPair { unix: RepoRelativePath, windows: RepoRelativePath, reason: NonEmptyReason }`, constructed once by `validate_pair(root, record, index) -> Result<PlatformAdapterPair, AdapterConfigError>`. Keep parsing/path/cfg validation in new `platform_adapters.rs`, parity collection in `portability/parity.rs`; portability.rs has call sites only and stays below 1000 non-test lines.
2. Resolve configured files and their real enclosing out-of-line module declarations, including differently named unix_socket/named_pipe. Require existing distinct confined .rs files, Unix/Windows enclosing cfg and production counterparts. Resolve ancestry before whole-file/rule exclusions; excluding a configured file neither makes it nonexistent nor invalidates the pair.
3. Suppress only PORT-010 for the paired enclosing Unix module declaration and inherited-private contents. Retain current checks for separately Unix-gated public/restricted items, unrelated parent/sibling items and unpaired production items; retain all other rules. Do not add public API equivalence or workspace-wide adapter inference. Apply k1 rule/path filters after structural parity decisions; --rule-filter never bypasses malformed config validation.
4. Extend installer schema/rendering for exactly three nonempty string fields and regenerate k1’s catalog after own_keys changes. Render inline-table arrays; compare parsed TOML, not bytes against the array-of-tables example. Python checks structure only; Rust checks files/cfg/relationships once. Platform adapter configuration is optional: when supplied, enforce valid declarations; when absent, preserve prior parity results for identical inputs; when [] is supplied, add no behavior.
5. Add the issue-derived #372 separate-module fixture and CLI regression. No matching upstream implementation or PORT-010 testcase exists at atm-core c1f3ee7a86414aa58161fdf9c1c5bc5f5aef4569 or fenix c983f96a301af01ea584bc0ec1bc7b2cca5a9742 in .just/tests, tools, or crates/sc-lint-boundary/src/{tests,portability}.rs: unix_socket_path is PORT-005 and fenix sc-lint.toml is an exclusion workaround. Reuse sc-lint collect_parity_findings tests; do not claim an upstream testcase port. Rust owns the rule; Python only renders/validates installer shape.

### Configuration and errors
```toml
[[tool.sc-lint.analyzers.portability.platform_adapters]]
unix_module = "crates/transport/src/unix_socket.rs"
windows_module = "crates/transport/src/named_pipe.rs"
reason = "Reviewed private transport adapter."
```
JSON `analyzers.portability.platform_adapters` is the identical record array. Negative matrix:

| Case | Rust code suffix after ANALYZER_CONFIG. | Repair |
|---|---|---|
| Non-array/non-table, missing field, non-string or empty field | WRONG_TYPE | Supply three nonempty strings |
| Unknown field | UNKNOWN_KEY | Remove the named field |
| Absolute/.. escape or non-.rs path | ADAPTER_PATH | Use a confined repository-relative .rs path |
| Missing file | ADAPTER_MISSING | Supply the implementation file |
| Same canonical file or repeated pair | ADAPTER_DUPLICATE | Use a unique pair of distinct files |
| Undeclared or wrongly gated module | ADAPTER_CFG | Declare under the matching #[cfg(unix/windows)] parent |
| Test-only counterpart | ADAPTER_TEST_ONLY | Supply a production counterpart |

AdapterConfigError is a closed enum for those semantic cases, carrying index, field, offending value, cause and the listed recovery; display retains stable code through CLI exit 3. Installer rejects the first two structural rows (existing conflict exit 2); rendered semantic negatives are rejected by Rust, without a second Python filesystem/cfg validator.

## Authoritative acceptance criteria
1. `issue372_separate_adapter_pair` in src/tests.rs uses real parent declarations and private helpers: pre-fix PORT-010, post-fix none at covered sites. Record that command/status/rule evidence in PR validation. `issue372_retains_public_and_unrelated_parity` covers pub/restricted/unrelated cases and retained other rules; current same-scope and cfg(test) cases remain passing.
2. `issue372_invalid_adapter_matrix` covers every table row and exit mapping; `issue372_filter_precedence_and_empty` covers exclude_paths, exclude_paths_by_rule and --rule-filter together, nonmatching rules, and absent/[] byte-equivalent findings.
3. `issue372_cli_configured_pair` in tests/cli.rs loads the fixture through the real standalone CLI. `test_issue372_installer_roundtrip` in tests/adoption/test_install.py covers all structural negatives, parsed JSON/TOML equivalence, Rust parsing of rendered semantic cases, idempotence and nonmutating --dry-run drift.

## Unblock Milestone
Committed pair parser/parity API and tests unblock k3's stack placement and k4's installer integration; no additional gate.

## Authoritative validation
`cargo test -p sc-lint-portability issue372`; `python3 -m unittest discover -s tests/adoption -p test_install.py`; finish `just lint`, then `just test`.

## Non-closure
No publishing, version bump, report-schema change, consumer-specific defaults, unrelated tooling or skill changes. Final user guides and release notes belong solely to k10; governing amendments land in planning before dispatch.
