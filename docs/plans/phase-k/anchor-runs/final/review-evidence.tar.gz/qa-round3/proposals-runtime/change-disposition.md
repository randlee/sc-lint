# Review-round3 proposal report

Source inputs: exact immutable final-item snapshots for k8/k9/k10 and `/tmp/phase-k-plan/review-round3/root-current.md`. These are proposals only; no Beads or repository writes and no judge calls were made. Existing anchors and approved contracts are retained.

## lint-k-8
- Replaced the vague path-key migration clause with one exact diagnostic/action template in a literal text block with interpolation placeholders, alias rule, virtual-root-only `workspace.` rule, package named `workspace` case, error code and exit behavior; root and k-10 refer to the same migration contract.
- Added the matching compatibility sentence to the root summary and required Unreleased entry to k-10 D1.
- Numbered acceptance criteria and mapped each to existing D1–D4; preserved named DNS regressions and all existing coverage.
- Trace: ANC005/006/007/008 per the carried QA findings; #390 existing adapter scope and ADR-017 external-adapter responsibility.

## lint-k-9
- Added a six-deliverable sizing breakdown totaling 12–22h and stated why the planner/executor/serialized-result contract must remain one sprint.
- Made ACs numbered and mapped to D1–D6.
- Specified literal Rust definitions and field types plus concrete parse/method signatures for `ProfileName` and `Target`, all requested Rust definitions and field types, and exact `SystemAdapter` additions grounded in current source; concrete `SystemAdapter` method signatures grounded in current `StepPlan`, `StepReport`, and `ConsumerProfileStep`; and `workflow.rs` ownership of existing workflow `steps` serialization.
- Trace: ANC commitments in the frozen item; RBP-001 (stable code/cause/recovery/docs) and RBP-004 (validated semantic values as newtypes). No unrelated trait or type-system scope added.

## lint-k-10
- Added a single-sprint estimate breakdown totaling 16–24h and explained why one reconciled current-facing docs set should be completed together.
- Made D3/D4 explicitly document and link to owning k1–k4/k6–k9 sprint contracts instead of duplicating their implementation detail.
- Made staged docs checks require the locked branch-built binary and branch docs bundle in the existing executable-relative bundle layout; run the staged executable to exercise executable-relative bundle discovery.
- Added k8's path-key compatibility note to Unreleased and numbered AC-to-D mappings.
- Trace: ANC docs boundary and existing release artifact/docs-bundle code; no new product behavior or docs framework.

## root
- Added only the specific k8 compatibility break and migration/release-note obligation; existing phase scope, exclusions, stack plan, and estimates are otherwise retained.
