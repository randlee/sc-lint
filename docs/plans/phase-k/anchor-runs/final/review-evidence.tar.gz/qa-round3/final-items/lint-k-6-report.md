## Anchor gate: plan · lint-k-6

Run `plan-20261013T033905Z-lint-k-6`, model `jev-1.13.0`, threshold 0.6. Counts: satisfied 6, not_applicable 3.

All judged anchors are satisfied or not applicable.

