## Anchor gate: plan · lint-k-7

Run `plan-20261013T033935Z-lint-k-7`, model `jev-1.13.0`, threshold 0.6. Counts: satisfied 7, not_applicable 2.

All judged anchors are satisfied or not applicable.

