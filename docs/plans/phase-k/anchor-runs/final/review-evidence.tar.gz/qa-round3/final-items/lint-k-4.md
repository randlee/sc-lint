# Sprint k-4 — optional-manifest-policy

## Scope boundary
#136; 20–32h for three individually tested families sharing one parser/inventory integration. ADR-004/016/017, REQ-SCB-015/019/021, REQ-PRODUCT-023 and ANC-001–009 govern. Rust ports applicable atm-core behavior/tests, not consumer identities. k1 owns neutral config access; k3 owns validated inventory and canonical package resolution. Live Beads dependencies and phase-k.jsonl define sequencing; project-plan links this phase.

## Authoritative deliverables
See Deliverables.

## Deliverables
1. Register `manifest_dependency_allowlists`, `global_dependency_ownership`, `manifest_section_rules` in BOUNDARY_CATALOG.own_keys. Read through k1 own_tables; parse into the private types below. Thread settings-derived policy into private configured-analysis functions; public AnalyzeOptions and analyze_workspace signatures stay unchanged. Empty/absent families add no checks; absent all families retains the old inventory-free manifests fast path, even with missing/invalid boundaries. Load k3 ValidatedInventory only for a nonempty allowlist family; ownership/sections do not need it.
2. Port allowlist enforcement: all direct normal/dev/build/target dependencies count, using Cargo metadata package identity for renames. A nonempty family needs exactly one entry per active boundary owner; duplicate, nonworkspace or inactive owners and missing active-owner entries fail. Active states are active/stub_landed/concrete_landed/unix_implemented_windows_pending. Present allowed_dependencies=[] allows none; stale allowed-minus-actual and disallowed actual-minus-allowed fail. Optional record locks require every listed parsed record to belong to that owner and its normal/dev dependency union to equal the allowlist; when that record has nonempty allowed_dev_dependencies, additionally compare actual production (normal/build including target) and dev sets separately against the record's respective sets.
3. Port ownership enforcement: declarations may occur only in allowed_manifest_paths; source mentions only beneath allowed_source_roots. Empty lists permit none. Reuse source discovery and port the bounded upstream dependency_import_patterns detector into ownership.rs: hyphen→underscore crate spelling, `crate::`, `use crate`, `extern crate crate`, skipping upstream comment-only lines. This intentionally preserves textual matches (including string-literal mentions) and external crates that graph/reference_collector's syn/workspace-root model does not capture; no new generic parser or duplicate Python scanner.
4. Port section enforcement: match owner manifest and actual dependency package, then exact section string including target qualifiers. `dev-dependencies` does not match `target.cfg(unix).dev-dependencies`; an empty list forbids every occurrence. Preserve accepted upstream strings rather than introducing a stricter grammar.
5. Fix codes: SCB-MANIFEST-003 disallowed dependency, -004 ownership, -005 section restriction, -006 stale/inconsistent policy (including owner coverage/record locking). Register RuleId/as_str, ALL_BOUNDARY_IDS, DEFAULT_FAIL_IDS, manifests family, failure/sort classification, defaults and analyzer-owned path extraction for k1 filtering. All default to Fail. Reuse owner_ids[0] for real manifest/source paths; never decode messages. Regenerate k1 installer catalog; update existing boundary record gates without loosening dependencies.
6. Extend adoption schema/rendering; Python checks shape and generated catalog only. Rust alone enforces policy/filesystem semantics. Preserve ignored unknown nested fields and strict analyzer-level keys. `lint_manifests.py` remains the existing legacy Cargo hygiene adapter and never reads these three keys; the sole new-policy entry point is Rust `lint sc-boundary --rule-filter manifests`, including Python's existing sc_lint.run delegation. Test that exposure; no new native export or independent Python policy implementation.

### Private types and module homes
```rust
struct ManifestAllowlist { owner: PolicyPath, allowed: BTreeSet<DependencyPackageName>, records: Vec<PolicyPath> }
struct DependencyOwnership { dependency: DependencyPackageName, manifests: Vec<PolicyPath>, roots: Vec<PolicyPath>, manifest_message: String, source_message: String }
struct SectionRule { owner: PolicyPath, dependency: DependencyPackageName, sections: Vec<ManifestSection>, message: String }
struct DependencyPackageName(String); // actual package, distinct from dependency key
struct ManifestSection(String); // exact section token, including target qualifier
struct PolicyPath(PathBuf); // preserve upstream path acceptance; normalize for comparisons
fn parse_policy(settings: &AnalyzerSettings) -> Result<ManifestPolicyConfig, AnalyzerConfigError>;
fn analyze_policy(root: &Path, metadata: &Metadata, inventory: Option<&ValidatedInventory>, config: &ManifestPolicyConfig) -> Result<Vec<Finding>, BoundaryError>;
```
Use `manifest_dependency_policy/{mod,config,allowlist,ownership,sections}.rs`, each below 1000 non-test lines; tests live in tests/issue136.rs. Reuse k3 WorkspacePackageResolver for workspace identity and existing Cargo metadata dependency names for external/renamed packages. PolicyPath does not impose k2's confined-source constraint on formerly accepted upstream paths; adapters convert real finding paths to k1 RepoRelativePath.

### Public shape and neutral example
```toml
[[tool.sc-lint.analyzers.boundary.manifest_dependency_allowlists]]
owner_manifest_path = "crates/store/Cargo.toml"
allowed_dependencies = ["core-api", "db-driver"]
boundary_record_path = ["boundaries/store/store.toml"]
[[tool.sc-lint.analyzers.boundary.global_dependency_ownership]]
dependency = "db-driver"
allowed_manifest_paths = ["crates/store/Cargo.toml"]
allowed_source_roots = ["crates/store/src"]
manifest_message = "Only store may depend on db-driver."
source_message = "Only store source may import db-driver."
[[tool.sc-lint.analyzers.boundary.manifest_section_rules]]
owner_manifest_path = "crates/app/Cargo.toml"
dependency_package = "fixture-kit"
allowed_sections = ["dev-dependencies", "target.cfg(unix).dev-dependencies"]
message = "fixture-kit belongs in declared test sections."
```
One fixture supplies parsed TOML and JSON `analyzers.boundary` equivalents. Render JSON record arrays as inline TOML arrays; compare parsed structures. Required nonempty strings: owner_manifest_path, dependency/dependency_package and all messages. allowed_dependencies is required array of nonempty strings, possibly empty. boundary_record_path is absent, nonempty string, or nonempty array of nonempty strings. Ownership path arrays and allowed_sections default []; their elements are strings and retain upstream acceptance of empty strings. Unknown nested fields are ignored. Wrong outer/member/known-field types, missing required fields or forbidden empty values are indexed ANALYZER_CONFIG.WRONG_TYPE (Rust exit 3; installer structural conflict exit 2), naming field, cause and expected repair. Unknown analyzer keys are UNKNOWN_KEY. Policy findings carry stable kind plus path/package/section: disallowed→remove dependency or review/add permission; stale→remove unused permission; owner/lock mismatch→align named owner/record lists; ownership/section→consumer message plus offending occurrence and allowed destinations/sections.

### Reuse and regression mapping
Pin: atm-core c1f3ee7a86414aa58161fdf9c1c5bc5f5aef4569 `.just/lint_boundaries.py` readers manifest_dependency_allowlists/dependency_ownership_rules/manifest_section_rules, collectors collect_manifest_dependency_allowlist_violations/collect_special_case_violations; source tests `.just/tests/test_lint_boundaries.py`. Actual Rust ports:

| Rust test in tests/issue136.rs | Pinned test/case |
|---|---|
| issue136_added_and_stale | test_manifest_dependency_allowlist_rejects_new_dev_or_test_dependency; test_run_rejects_manifest_dependency_not_allowlisted; test_manifest_dependency_allowlist_rejects_stale_dependency |
| issue136_record_locks | test_manifest_dependency_allowlist_can_lock_a_boundary_record_to_the_enforced_list; test_manifest_dependency_allowlist_locks_every_listed_boundary_record |
| issue136_ownership | test_collect_boundary_violations_flags_direct_rusqlite_dependency; test_collect_boundary_violations_flags_rusqlite_source_import_outside_store |
| issue136_sections | test_collect_boundary_violations_flags_non_dev_atm_core_edge |

Those names are provenance, never product policy defaults; source snippets are adapted to neutral fixture crates.

## Authoritative acceptance criteria
1. The four mapped tests reproduce missing #136 enforcement before the fix and expected post-fix codes/status; PR validation records commands and before/after output. Cover source comments/string mentions, exact target sections, both record-lock forms and production/dev splits.
2. `issue136_optional_config_matrix` adds absent/[] vs present-empty, active-owner completeness/duplicates/inactive/nonworkspace owner, malformed shape matrix, ignored nested keys, renamed dependency and two unrelated workspaces. Missing/invalid boundaries with absent policy must preserve previous findings byte-for-byte; supplied policy is enforced. Every new rule defaults to Fail and honors rule/path filtering.
3. `test_issue136_installer_roundtrip` in tests/adoption/test_install.py validates the shared fixture, all structural negatives and Rust parsing of rendered output. `.just/tests/test_phase_k_analyzer_delegation.py::test_issue136_native_run_parity` compares direct binary with existing sc_lint.run using a built wheel and asserts lint_manifests never reads new-family keys; no new exports. `issue136_product_dispatch` in crates/sc-lint/src/tests.rs covers the manifests route and IDs.

## Unblock Milestone
Committed three-family Rust policy, installer round-trip and dispatch tests complete the analyzer stack contract consumed by later integration; no additional gate.

## Authoritative validation
`cargo test -p sc-lint-boundary --test issue136`; `cargo test -p sc-lint issue136`; boundary `installer_catalog_matches_rust`; `python3 -m unittest discover -s tests/adoption -p test_install.py`; `python3 -m unittest discover -s .just/tests -p test_phase_k_analyzer_delegation.py` with the built wheel and SC_LINT_BIN=target/debug/sc-lint; repository boundary self-lint. Finish `just lint`, then `just test`.

## Non-closure
No publishing, version bump, report-schema change, consumer-specific defaults, unrelated tooling or skill changes. Final user guides and release notes belong solely to k10; governing amendments land in planning before dispatch.
