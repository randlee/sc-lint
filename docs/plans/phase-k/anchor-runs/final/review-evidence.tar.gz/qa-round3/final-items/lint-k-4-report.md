## Anchor gate: plan · lint-k-4

Run `plan-20261013T033836Z-lint-k-4`, model `jev-1.13.0`, threshold 0.6. Counts: satisfied 8, not_applicable 1.

All judged anchors are satisfied or not applicable.

