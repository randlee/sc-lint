```json
{
  "schema_version": "1.0.0",
  "success": true,
  "canceled": false,
  "aborted_by": null,
  "data": {
    "gate": "plan",
    "bead_id": "lint-k-7",
    "run_id": "plan-20261013T033935Z-lint-k-7",
    "run_path": "docs/plans/phase-k/anchor-runs/qa-r3/plan-20261013T033935Z-lint-k-7.json",
    "dry_run": false,
    "reused_run": false,
    "exit_code": 0,
    "pass": true,
    "failing": [],
    "errors": [],
    "results": [],
    "overrides_applied": [
      "ANC-001",
      "ANC-002",
      "ANC-005",
      "ANC-006",
      "ANC-007",
      "ANC-008",
      "ANC-009",
      "ANC-003",
      "ANC-004"
    ],
    "item_truncated": false,
    "shortened": [],
    "report_markdown": "## Anchor gate: plan · lint-k-7\n\nRun `plan-20261013T033935Z-lint-k-7`, model `jev-1.13.0`, threshold 0.6. Counts: satisfied 7, not_applicable 2.\n\nAll judged anchors are satisfied or not applicable.\n\n"
  },
  "error": null,
  "metadata": {
    "duration_ms": 1200,
    "tool_calls": 9,
    "retry_count": 0,
    "correlation_id": "lint-k-7-final-r3"
  }
}
```
