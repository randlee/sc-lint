```json
{
  "schema_version": "1.0.0",
  "success": true,
  "canceled": false,
  "aborted_by": null,
  "data": {
    "gate": "plan",
    "bead_id": "lint-k-4",
    "run_id": "plan-20261013T033836Z-lint-k-4",
    "run_path": "docs/plans/phase-k/anchor-runs/qa-r3/plan-20261013T033836Z-lint-k-4.json",
    "dry_run": false,
    "reused_run": false,
    "exit_code": 0,
    "pass": true,
    "failing": [],
    "errors": [],
    "results": [],
    "overrides_applied": [
      "ANC-001",
      "ANC-002",
      "ANC-003",
      "ANC-005",
      "ANC-006",
      "ANC-007",
      "ANC-008",
      "ANC-009",
      "ANC-004"
    ],
    "item_truncated": false,
    "shortened": [],
    "report_markdown": "## Anchor gate: plan · lint-k-4\n\nRun `plan-20261013T033836Z-lint-k-4`, model `jev-1.13.0`, threshold 0.6. Counts: satisfied 8, not_applicable 1.\n\nAll judged anchors are satisfied or not applicable.\n\n"
  },
  "error": null,
  "metadata": {
    "duration_ms": 1500,
    "tool_calls": 10,
    "retry_count": 1,
    "correlation_id": "lint-k-4-final-r3"
  }
}
```
