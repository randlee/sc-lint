import json, pathlib, hashlib, subprocess, sys, re
w=pathlib.Path('/Users/randlee/github/sc-lint-worktrees/plans/phase-k'); root=w/'docs/plans/phase-k'; skill=w/'.codex/skills/plan-anchoring'
f=pathlib.Path(sys.argv[1]); src=f.read_text(); result=json.loads(src.split('```json\n')[1].split('```')[0]) if src.startswith('```') else json.loads(src)
tmp=f.with_name('result-install-validated.json');tmp.write_text(json.dumps(result,indent=2)+'\n')
subprocess.run(['python3',str(skill/'scripts/anchor_tuning_contract.py'),'result',str(tmp)],check=True)
d=result['data'];assert result['success'] and d['accepted']; gate={'planning':'plan','development':'dev'}[d['gate']]
aid=d['tuning_history_after']['events'][-1]['authority']['anchor_id']
a=json.loads((root/'anchors.json').read_text());r=next(x for x in a['anchors'] if x['id']==aid)
hist=d['tuning_history_after']; canonical=json.dumps(hist,sort_keys=True,separators=(',',':'),ensure_ascii=False);digest=hashlib.sha256(canonical.encode()).hexdigest();assert digest==d['tuning_history_after_sha256']
questions=d['sealed_question_set']['questions'];qcanon=json.dumps({"questions":questions},sort_keys=True,separators=(',',':'),ensure_ascii=False);assert hashlib.sha256(qcanon.encode()).hexdigest()==d['sealed_question_set']['digest']
last=hist['events'][-1];assert last['authority']['anchor_version']==r['version'] and last['authority']['anchor_id']==aid
out=root/'anchor-runs'/'tuned'/f'{aid}-{gate}-qa-r3';out.mkdir(parents=True,exist_ok=True)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');(out/'history.json').write_text(canonical+'\n');(out/'questions.json').write_text(json.dumps({'questions':questions},indent=2)+'\n')
body=f'# {aid} {gate} questions\n\nAccepted independent tuning; question digest {d["sealed_question_set"]["digest"]}.\n\n```json\n'+json.dumps({'questions':questions},indent=2)+'\n```\n\nCanonical tuning history SHA-256: '+digest+'\n\n```tuning-history\n'+canonical+'\n```\n'
(out/'bead.md').write_text(body)
subprocess.run(['bd','update','--actor','flint',r['beads']['plan_questions' if gate=='plan' else 'dev_questions'],'--body-file',str(out/'bead.md')],cwd=w,check=True)
r.setdefault('tuning_history',{})[gate]=hist
(root/'anchors.json').write_text(json.dumps(a,indent=2)+'\n')
print('Installed',aid,gate)
