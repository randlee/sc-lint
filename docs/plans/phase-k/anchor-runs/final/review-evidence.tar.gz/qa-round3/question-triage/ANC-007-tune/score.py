import importlib.util,json,pathlib,statistics
p=pathlib.Path('/tmp/phase-k-plan/review-round3/question-triage/ANC-007-tune')
req=json.loads((p/'request.json').read_text());oracle=json.loads((p/'oracle.json').read_text());pool=json.loads((p/'candidates.json').read_text());rows=json.loads((p/'attempts.json').read_text());by={(x['candidate_id'],x['case_id'],x['repeat']):x for x in rows}
sp=importlib.util.spec_from_file_location('j',req['runtime']['script']);J=importlib.util.module_from_spec(sp);sp.loader.exec_module(J)
rolemap={'relevance':'relevant','compliance':'addressed','conflict':'contradicted'};results=[]
for v in pool:
 cells=[];correct=verdicts=stable=0;bad=[];conf=[]
 for c in oracle['cases']:
  pair=[by[v,c['case_id'],r] for r in (1,2)]
  assert all('response' in a for a in pair) and pair[0]['request_sha256']==pair[1]['request_sha256']
  ans=[a['response']['answers'] for a in pair];roles={}
  for role in c['expected']:
   vals=[J.answer_choice(a[role]) for a in ans];ok=all(x[0]==c['expected'][role] for x in vals);roles[role]={'expected':c['expected'][role],'choices':[x[0] for x in vals],'confidences':[x[1] for x in vals],'exact':ok,'stable':vals[0][0]==vals[1][0]};correct+=ok;conf.append(min(x[1] for x in vals))
  vs=[J.decide(a,rolemap,0.0,'directive')[0] for a in ans];vok=vs==[c['verdict']]*2;verdicts+=vok;st=all(x['stable'] for x in roles.values());stable+=st
  if not (vok and st and all(x['exact'] for x in roles.values())):bad.append(c['case_id'])
  cells.append({'case_id':c['case_id'],'roles':roles,'expected_verdict':c['verdict'],'verdicts':vs,'verdict_exact':vok,'stable':st})
 results.append({'candidate_id':v,'exact_role_cells':correct,'total_role_cells':len(oracle['cases'])*3,'exact_semantic_verdicts':verdicts,'total_semantic_verdicts':len(oracle['cases']),'stable_cases':stable,'total_cases':len(oracle['cases']),'confidence_at_0_8':sum(x>=.8 for x in conf),'minimum_confidence':min(conf),'mean_confidence':statistics.mean(conf),'bad_cases':bad,'cells':cells})
(p/'scores.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
for x in results: print(x['candidate_id'],x['exact_role_cells'],'/',x['total_role_cells'],'verdict',x['exact_semantic_verdicts'],'/',x['total_semantic_verdicts'],'stable',x['stable_cases'],'/',x['total_cases'],'conf>=.8',x['confidence_at_0_8'],'bad',x['bad_cases'])
