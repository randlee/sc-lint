import concurrent.futures,hashlib,importlib.util,json,os,pathlib
p=pathlib.Path('/tmp/phase-k-plan/review-round3/question-triage');w=pathlib.Path('/Users/randlee/github/sc-lint-worktrees/plans/phase-k')
Jpath=w/'.codex/skills/plan-anchoring/scripts/jev_judge.py';sp=importlib.util.spec_from_file_location('j',Jpath);J=importlib.util.module_from_spec(sp);sp.loader.exec_module(J);key=os.environ['TYPESAFE_API_KEY'].strip();J.check_api_key(key)
qs=json.loads(pathlib.Path('/tmp/phase-k-plan/planning-overrides.json').read_text());raw=p/'raw';raw.mkdir(exist_ok=True)
jobs=[]
for anc in ('ANC-001','ANC-007'):
 o=json.loads((p/(anc+'-oracle.json')).read_text());assert o['frozen_before_live'];extra=o['cases'][-2:]
 for c in extra:
  for repeat in (1,2):jobs.append((anc,c,repeat))
def send(job):
 anc,c,r=job;q=qs[anc]['questions'];fn=f"{anc}__{c['case_id']}__r{r}";body={'model':'jev-latest','questions':q,'state':c['state']};by=J.encode_body(body);(raw/(fn+'.request.json')).write_bytes(by);z=J.call_jev(body,key,45.0);J.validate_response(z,q);(raw/(fn+'.response.json')).write_text(json.dumps(z,indent=2,ensure_ascii=False)+'\n');choices={k:list(J.answer_choice(v)) for k,v in z['answers'].items()};ver0=J.decide(z['answers'],{'relevance':'relevant','compliance':'addressed','conflict':'contradicted'},0.0,'directive')[0];ver6=J.decide(z['answers'],{'relevance':'relevant','compliance':'addressed','conflict':'contradicted'},0.6,'directive')[0];return {'anchor_id':anc,'case_id':c['case_id'],'repeat':r,'request_sha256':hashlib.sha256(by).hexdigest(),'choices':choices,'oracle':c['expected'],'verdict_threshold_0':ver0,'verdict_threshold_0_6':ver6}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(send,jobs))
(p/'current-control-answers.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False)+'\n')
for x in rows:print(x['anchor_id'],x['case_id'],x['repeat'],x['choices'],'v0',x['verdict_threshold_0'],'v6',x['verdict_threshold_0_6'])
