import json, hashlib, pathlib, subprocess, sys
root=pathlib.Path('/Users/randlee/github/sc-lint-worktrees/plans/phase-k')
out=pathlib.Path('/tmp/phase-k-plan/review-round3')
anchors=json.loads((root/'docs/plans/phase-k/anchors.json').read_text())['anchors']
overrides=json.loads(pathlib.Path(sys.argv[1]).read_text())
selected=json.loads(pathlib.Path(sys.argv[2]).read_text())
rows=[]
for bead,filename in selected.items():
 runpath=root/filename; run=json.loads(runpath.read_text()); src=pathlib.Path(run['item']['source']); text=src.read_text()
 live=json.loads(subprocess.check_output(['bd','show',bead,'--json'],text=True))[0]['description']
 assert live==text,(bead,'source drift')
 assert not run['dry_run'] and not run['item']['truncated'] and not run['summary'].get('shortened'),bead
 assert len(run['results'])==9,bead
 for r in run['results']:
  a=next(a for a in anchors if a['id']==r['anchor_id'])
  q=overrides[a['id']]['questions']
  digest=hashlib.sha256(json.dumps(q,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
  assert r['questions_sha256']==digest,(bead,a['id'],'question mismatch')
  assert r['anchor_version']==a['version'] and r['statement']==a['statement'],(bead,a['id'],'anchor drift')
  assert r['verdict'] in ['satisfied','not_applicable'],(bead,a['id'],r['verdict'])
 rows.append({'bead':bead,'run':filename,'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'chars':len(text),'pass':True})
assert len(rows)==9
(out/'final-source-audit.json').write_text(json.dumps({'pass':True,'items':rows},indent=2)+'\n')
print('PASS: 9 complete live descriptions match their runs; current sealed questions and anchor versions match; all 81 cells pass.')
