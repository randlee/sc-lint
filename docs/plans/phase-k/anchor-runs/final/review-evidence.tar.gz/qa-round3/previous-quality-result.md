# Plan QA round 2: FAIL

`validate-plan --root lint-phase-k` exit 0: plan valid, 9 sprints (run from the plans/phase-k worktree at c79c210aad6ff8725f64385aea454361b1d6f053; k-5 deferred/scope-excluded). Step b clean. Plan text re-pulled for all ten beads; only lint-k-8 differs from the reviewed text (D3 optional-table sentence, wording clarification per flint 01M4SMSSSD1PB7QTZ99W9H3BR6).

- lint-k-9 important plan-scope-reviewer scope (R1-line-084 / PLAN-SCOPE-007) OPEN: k-9 is still one 12-22h sprint with 6 deliverables across planner, grammar, bootstrap, installer, CI and execution; no sentence justifies single-sprint sizing and acceptance items are not numbered or mapped to deliverable numbers
- lint-k-10 important plan-scope-reviewer scope (R1-line-085 / PLAN-SCOPE-008) OPEN: 0.7.* range is now finite and a five-group map bounds the review, but k-10 is one 16-24h sprint with 40 owned paths and no sentence justifies keeping retroactive and Phase K docs together (or splitting)
- lint-k-10 important plan-scope-reviewer acceptance (R1-line-086 / PLAN-SCOPE-009) OPEN: the artifact used for the `sc-lint docs*` checks is still unspecified ('existing installed binary/wheel or installer', 'installed sc-lint docs'); name the exact artifact (e.g. branch-built binary plus staged docs-bundle) as a precondition
- lint-k-6 important plan-scope-reviewer acceptance (R1-line-088 / PLAN-SCOPE-011) OPEN: k-6 and k-8 (and k-7, k-9) have numbered deliverables but acceptance is unnumbered bullets not mapped to deliverable numbers; k-2/k-3/k-4 are fixed
- lint-k-9 important plan-scope-reviewer deliverable 1 (R1-line-090 / PLAN-SCOPE-013) OPEN: plan_consumer_lint signature and PlanDecision variants are stated, but there is still no Rust definition for ProfileName, Platform, PlatformScope, Target, CargoVerb, PlannedStep, SkipRecord or ProfilePlanError; SystemAdapter additions unstated; module that serializes skipped rows not named
- lint-k-8 important plan-scope-reviewer deliverable 1 (R1-line-095 / PLAN-SCOPE-018) OPEN: key grammar is specified, but the exact migration guidance string is not given, and manifest-path-key rejection is not in the root compatibility statement or in k-10 deliverable 1's Unreleased compatibility note
- lint-k-10 minor ceremony-qa deliverables 3-4 (R1-line-126 / CQA-F002) OPEN: k-10 D3/D4 still restate contracts already in k-3/k-4/k-7/k-8/k-9
- lint-k-3 minor ceremony-qa description (R1-line-128 / CQA-F004) OPEN: k-3 still carries boilerplate (Authoritative deliverables section, Non-closure block, pointer-only design/acceptance fields, repeated compatibility sentences)

Round 2 fix verification (filing reviewers only, scope locked to carried findings, no new findings raised): 125 carried ids judged: 117 fixed, 8 open, 0 regressed.
- arch-qa: 24/24 fixed (merge_ready true)
- req-qa: 65/65 fixed; judged against c79c210 text. lint-k-8 D3 was re-compared with the current sentence (absent optional table preserves prior findings/status on identical inputs; supplied table validated and enforced; explicitly empty table permits none): the only delta from the reviewed text is that sentence, and it carries the same contract R1-line-058 required, so R1-line-058 remains fixed.
- rust-best-practices-agent: 10/10 fixed (RBP-001/002/004 selected)
- ruthless-boundary-qa: 7/7 fixed
- ceremony-qa: 2 fixed (R1-line-076, R1-line-127), 2 open minor (R1-line-126, R1-line-128)
- plan-scope-reviewer: 17 fixed, 6 open (R1-line-084, 085, 086, 088, 090, 095), 0 regressed
- Unsolicited non-finding notes: residual ADR-017 citation note on R1-line-119 (arch-qa); no deletion target named for the Python cargo-shear validator and no-rule-constants guard covers install.py only (ruthless-boundary-qa); crates/sc-lint/src/tests.rs is co-owned across Stack A (k-3,k-4) and Stack B (k-6,k-7,k-9) and not listed as a touch point; the root `layer` field is undefined (plan-scope-reviewer).

- arch-qa (fix verification): PASS, 24 fixed
- req-qa (fix verification): PASS, 65 fixed
- rust-best-practices-agent (fix verification, practice_mode selected): PASS, 10 fixed
- ruthless-boundary-qa (fix verification): PASS, 7 fixed
- ceremony-qa (fix verification): 2 fixed, 2 open minor
- plan-scope-reviewer (fix verification): 17 fixed, 6 open important, 0 regressed
- No automatic req-qa/arch-qa sweep, full plan-scope review or screening panel ran (fix-verification precedence).

- Verdict is FAIL because six important carried findings remain open (all plan-scope-reviewer, wording/numbering/sizing-justification/type-definition corrections inside sprint docs). No blocking findings. Every blocking and every req-qa/arch-qa/rust-best-practices/ruthless-boundary finding is fixed.
- Required corrections: (1) k-9: one sentence justifying single-sprint sizing; number acceptance items and map to deliverable numbers; define the selection/skip/plan types and name the serializing module; (2) k-10: sizing justification (or split by document set); name the artifact for `sc-lint docs*` checks; (3) k-6/k-7/k-8/k-9: number acceptance items citing deliverable numbers; (4) k-8: state the migration guidance string and add manifest-path-key rejection to the root compatibility statement and k-10 D1 Unreleased note; (5) minor: trim k-10 D3/D4 restatements and k-3 boilerplate.
- Reviewer-subset next round: plan-scope-reviewer (6 ids) and ceremony-qa (2 ids) only.