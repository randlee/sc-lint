## Anchor gate: plan · lint-k-1

Run `plan-20261013T034016Z-lint-k-1`, model `jev-1.13.0`, threshold 0.6. Counts: satisfied 8, not_applicable 1.

All judged anchors are satisfied or not applicable.

