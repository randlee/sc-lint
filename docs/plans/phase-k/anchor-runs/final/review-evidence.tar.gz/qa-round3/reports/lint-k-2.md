## Anchor gate: plan · lint-k-2

Run `plan-20261013T033844Z-lint-k-2`, model `jev-1.13.0`, threshold 0.6. Counts: satisfied 6, not_applicable 3.

All judged anchors are satisfied or not applicable.

