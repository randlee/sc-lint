## Anchor gate: plan · lint-k-3

Run `plan-20261013T033851Z-lint-k-3`, model `jev-1.13.0`, threshold 0.6. Counts: satisfied 9.

All judged anchors are satisfied or not applicable.

