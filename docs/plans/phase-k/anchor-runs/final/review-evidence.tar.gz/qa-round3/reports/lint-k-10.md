## Anchor gate: plan · lint-k-10

Run `plan-20261013T033858Z-lint-k-10`, model `jev-1.13.0`, threshold 0.6. Counts: satisfied 1, not_applicable 8.

All judged anchors are satisfied or not applicable.

