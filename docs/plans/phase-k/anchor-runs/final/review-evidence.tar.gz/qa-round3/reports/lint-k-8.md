## Anchor gate: plan · lint-k-8

Run `plan-20261013T034542Z-lint-k-8`, model `jev-1.13.0`, threshold 0.6. Counts: satisfied 7, not_applicable 2.

All judged anchors are satisfied or not applicable.

