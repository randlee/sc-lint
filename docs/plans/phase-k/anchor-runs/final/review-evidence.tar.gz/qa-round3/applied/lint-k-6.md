# Sprint k-6 — managed-consumer-bootstrap

## Scope
Issue #388; 4–8h. Add direct managed execution; no Python/lint-rule changes, hooks, second executor, or atm-core policy. It must behave the same for unrelated consumer repositories: repository identity selects neither execution behavior nor policy, and ordinary consumers need no atm-core-specific configuration.

## Deliverables
1. Add `.sc-lint/bootstrap exec --config <file> -- <argv...>` to canonical assets and adoption copies. Activate existing managed install; invoke managed binary directly for `argv[0] == sc-lint` (never PATH); other argv[0] runs unchanged in the activated environment. Preserve argv/cwd/env/status; bypass profile dispatch. `--config` selects the existing sc-lint configuration input for this invocation; omission retains current `sc-lint.toml` discovery and introduces no required configuration or policy. Do not change ordinary bootstrap behavior.
2. Port sh/PowerShell resolver behavior from `randlee/atm-core@ebd2dfc1ce5be2295105ba2bc87787c2f9af274e:.just/sc_lint_binary.py`. Through sc-lint’s `.sc-lint/bootstrap exec` interface, preserve the applicable source cases’ inputs and expected assertions: `test_explicit_managed_binary_builds_analyzer_argv`, `test_explicit_managed_binary_ignores_a_path_decoy`, `test_windows_default_resolves_exe_and_propagates_child_exit_code`, `test_missing_managed_binary_tells_the_user_to_setup`, and `test_boundary_wrapper_reports_missing_binary_without_a_traceback`. No new Python helper/interpreter selection.
3. Update canonical assets, adoption copies, and root `.sc-lint/bootstrap(.ps1)` parity. Own `test_consumer_contract.py::test_root_helpers_match_the_generated_product_assets` and `crates/sc-lint/src/installer.rs::consumer_bootstrap_exposes_only_product_owned_operations` if operation allowlist changes. Generate neutral and atm-core-derived fixtures in `crates/sc-lint/src/tests.rs`.

## Acceptance and validation
1. **D1, D2:** Add `bootstrap_exec_does_not_reenter_consumer_profile`, `bootstrap_exec_uses_managed_product`, `bootstrap_exec_preserves_argv_and_exit_status`, `bootstrap_exec_reports_missing_managed_product`, `bootstrap_exec_supports_non_sc_lint_argv0`. Missing binary exits 1, says `just setup`, and never auto-setups or traces back. For #388, record a red-before result for the reported wrapper-recursion/direct-managed-execution failure, then show the same consumer scenario green after the change: managed execution bypasses profile re-entry and PATH decoys while preserving argv, cwd, environment, and status.
2. **D1, D3:** Verify PowerShell argv/cwd/env/status at runtime on Windows. Include a simpler consumer fixture with no atm-core-specific configuration. Run parity test, focused regressions, `just lint`, `just test`.

## Unblock Milestone
k-7 may start after k-6 commits the exec contract and canonical/adoption/root parity. Handoff only.

## Non-closure
No publishing/version bump or #195/#196/#198; k-10 owns docs.
