# Sprint k-3 — boundary-package-policy

## Scope boundary
#376/#377, 16–28h. One boundary sprint owns semantic validation and its immediately consuming package-policy pass: splitting would expose unvalidated records or duplicate identity resolution. ADR-004/017, REQ-SCB-015–023 and ANC-001–009 govern. Reuse applicable pinned atm-core code/tests in Rust; no consumer-specific defaults or second Python rule implementation. Existing simpler consumers continue to run sc-lint without atm-core-specific configuration. The same lint behavior supports consumer repositories beyond atm-core without hard-coded atm-core repository identities or policies. No unrelated tooling or skill changes; k-10 owns final user guides and release notes.

## Deliverables
1. Add `allowed_dev_dependents: Option<Vec<String>>` to RawDependenciesSection and `Option<BTreeSet<WorkspacePackageName>>` to PackageDependencyPolicy. Reuse WorkspacePackageResolver and WorkspacePackageName for canonical owner/dependent identities, including Cargo names/lib aliases; no new identity resolver. Preserve current participating record states and outgoing policy/forbidden-edge precedence.
2. Evaluate incoming edges once per canonical owner/dependent with the aggregation contract below. Emit stale permissions once as SCB-DEPENDENCY-004, deterministically identifying record/field. Unknown aliases remain invalid references; no transitive checks. Port atm-core c1f3ee7a86414aa58161fdf9c1c5bc5f5aef4569 `.just/lint_boundaries.py::collect_allowed_dependent_violations`; extend its runtime-only behavior with ADR-017's dev contract.
3. Add inventory/semantic.rs with validated RustIdent/PublicRustPath wrappers and ValidatedInventory. Preserve `load_boundary_inventory -> Result<BoundaryInventory>` and fatal TOML/I/O/schema/layout/duplicate-boundary_id failures. Aggregate all #377 semantic defects with the closed diagnostic kinds below; distinct boundary_ids with duplicate canonical (owner,name) produce failures, and ambiguous records never enter ValidatedInventory. Preserve owner-local composition symbols; only resolved external crate-qualified roots require dependent authorization.
4. Register SCB-BOUNDARY-004 and SCB-DEPENDENCY-004 in RuleId/as_str, ALL_BOUNDARY_IDS, DEFAULT_FAIL_IDS, defaults, BOUNDARY_CATALOG and analysis::{finding_is_failure,finding_sort_key}; both default to Fail. Boundary004 belongs to boundaries and dependencies; Dependency004 to dependencies. Semantic validation runs before the relevant graph/package passes; exact Boundary004 selection can validate inventory without graph analysis. Regenerate k1's catalog artifact.
5. Replace Python lint_boundaries' independent validators/key tables with a thin call via existing binary_path to `sc-lint --json --root <root> lint sc-boundary --rule-filter SCB-BOUNDARY-004`. Preserve run/validate_inventory adapter callers by projecting Rust messages/status only. No Python #376/#377 checks or native exports. Move existing Python tests to delegation/parity assertions; use BOUNDARY-ScLintBoundaryAnalyzer for closure, keep diagnostics crate-private and existing production dependency edges unchanged.

### Aggregation contract
R(P)=union R_i. D(P)=union(D_i if supplied, otherwise R_i). Supplied [] grants no dev permissions from that record and cannot revoke another record's grant. Absent dev fields preserve that optional feature's prior result; the authorized runtime union correction still applies. Normal/build dominates mixed normal+dev edges.

| Records owned by p | Runtime grants | Dev-only grants |
|---|---|---|
| A R=[q], D absent; B R=[r], D absent | q,r | q,r |
| A R=[q], D=[]; B R=[r], D absent | q,r | r |
| A R=[q], D=[s]; B R=[r], D absent | q,r | r,s |
| A R=[q], D=[]; B R=[], D=[] | q | none |

An entry is stale only if no live edge exists in any category it grants: runtime entries also grant dev-only when contributed by a record with D absent; explicit D grants only dev-only. Deduplicate by canonical (owner,dependent). Stale checking requires any owner record active (`active`, `stub_landed`, `concrete_landed`, `unix_implemented_windows_pending`), matching pinned BoundaryRecord.is_active; wholly planned/retired/reserved owners gain no stale failure.

### Internal validation contract
```rust
struct RustIdent(String); // validates Rust identifiers, including raw identifiers
struct PublicRustPath(Vec<RustIdent>);
struct ValidatedInventory { records: Vec<ValidatedRecord> } // private constructor
struct InventoryDiagnostic { record_path: PathBuf, field: String, kind: InventoryDiagnosticKind, cause: String, recovery: String }
enum InventoryDiagnosticKind { InvalidIdentifier, InvalidPublicPath, TraitOnlyConstructor, SelfForbiddenEdge, DuplicateOwnerName, UnapprovedCompositionRoot }
fn validate_inventory(raw: BoundaryInventory, resolver: &WorkspacePackageResolver) -> (ValidatedInventory, Vec<InventoryDiagnostic>);
fn analyze_package_policy(metadata: &Metadata, inventory: &ValidatedInventory) -> Result<PackagePolicyReport>;
```
ValidatedRecord contains validated identifiers/paths and canonical WorkspacePackageName policy fields; graph/policy analysis accepts ValidatedInventory, never raw records. Keep unrelated existing graph interfaces stable through a private adapter. Shared Finding schema is unchanged; kind carries the stable snake_case token for the enum variant and messages include record, field, cause and recovery.

| Kind | Cause and recovery |
|---|---|
| invalid_identifier / invalid_public_path | Invalid Rust syntax; supply a valid identifier/path, preserving accepted raw identifiers |
| trait_only_constructor | Concrete constructor on trait_only; omit it or use none |
| self_forbidden_edge | Canonical from/to are equal; remove/correct that edge |
| duplicate_owner_name | Distinct IDs reuse canonical owner/name; rename or remove the duplicate records |
| unapproved_composition_root | Resolved external root is not permitted; authorize the dependent or correct the root |
| stale_allowed_dependent (Dependency004) | No live edge in granted categories; remove the obsolete permission or restore the intended edge |

Port pinned build_boundary_record validation and applicable `.just/tests/test_lint_boundaries.py` tests `test_collect_boundary_violations_flags_unexpected_allowed_dependent`, `test_collect_boundary_violations_flags_stale_allowed_dependent_without_live_edge`, and `test_collect_boundary_violations_flags_forbidden_edge_even_when_planned`; reuse BASE_BOUNDARY_TOML/record fixtures for #377 mutations. Do not port unrelated upstream checks. Local roots and absent trait_only constructor follow accepted ADR-017 even where upstream differs.

## Authoritative acceptance criteria
1. src/tests.rs `issue376_union_matrix` covers all rows, aliases, fallback-dev/mixed liveness and forbidden precedence. Concrete edges: q normal→p, r dev→p; A R=[q],D=[r], B R=[q],D=[] passes once; removing r from A yields one denial. `issue376_stale_active_gate` covers every state and stale dedup. Record pre-fix failures and post-fix results in PR test evidence.
2. `issue377_semantic_mutations` covers every kind, valid raw identifiers/local and authorized external roots; `issue377_aggregates_and_keeps_fatal_errors` covers combined defects, deterministic context, distinct-ID duplicate exclusion with Fail, and all existing fatal loader cases. These live in src/tests.rs and must fail before the corresponding fix. For both #376 and #377, include an issue-linked regression reproducing the corresponding reported consumer failure; record it failing before its fix and passing afterward. Generic mutation or success tests do not substitute for that reproducer.
3. `issue377_rule_registration_and_dispatch` in crates/sc-lint/src/tests.rs verifies both IDs, default failure, boundaries/dependencies selection and stable order. `.just/tests/test_lint_boundaries_rust_parity.py::test_issue377_delegate_parity` compares direct Rust and Python messages/status; adapter unit tests assert exact delegation argv and forbid reintroduced validator functions/tables.

## Unblock Milestone
Committed validated inventory, canonical policy and diagnostic interfaces plus regressions unblock k4; k3 is based on k2 in the analyzer stack.

## Authoritative validation
`cargo test -p sc-lint-boundary issue376`; `cargo test -p sc-lint-boundary issue377`; `cargo test -p sc-lint issue377`; boundary `installer_catalog_matches_rust`; `python3 -m unittest discover -s bindings/sc-lint-py/python/sc_lint/tests -p test_lint_boundaries.py`; `python3 -m unittest discover -s .just/tests -p test_lint_boundaries_rust_parity.py`, using the built wheel and SC_LINT_BIN pointing at target/debug/sc-lint. Run repository boundary self-lint, then finish `just lint` and `just test`.

