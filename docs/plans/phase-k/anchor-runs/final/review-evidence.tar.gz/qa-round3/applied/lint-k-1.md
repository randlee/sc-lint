# Sprint k-1 — rule-path-exclusions

## Scope boundary
#385: finding-level exclusions and the shared configuration contract consumed by k2/k4. Effort 10–16h. ADR-013/017, REQ-PRODUCT-023, ANC-001–009 govern; Rust owns semantics, Python remains installation/rendering glue. This is one support contract with thin production integrations, not new analyzer policies. Existing simpler consumers continue to run sc-lint with ordinary settings and no atm-core-specific configuration; the new map adds no required consumer key.

## Authoritative deliverables
See Deliverables.

## Deliverables
1. Add optional `exclude_paths_by_rule: BTreeMap<CatalogRuleId, Vec<String>>` to AnalyzerSettings and COMMON_KEYS. Resolve exact catalog IDs only; reject family/unknown keys as ANALYZER_CONFIG.UNKNOWN_RULE with key `exclude_paths_by_rule`. Reject non-table maps, non-array values and non-string elements as WRONG_TYPE; analyzer exit 3. Retain existing glob/normalization, exclude_rules, exclude_paths and fail_rules semantics.
2. Centralize filtering/status in `apply_with_paths`, below; existing `apply` delegates with path=None. Keep the map predicate private and typed. Add neutral `own_tables` for k2/k4; it checks only array/table shape with indexed WRONG_TYPE context. Analyzer-specific parsing stays in its owning crate; no second TOML read bypassing catalog validation.
3. Route real portability/runtime findings through that helper using their private source_path before conversion. Boundary extracts SCB-MANIFEST-001/002 paths from owner_ids[0], produced by manifest_policy::relative_manifest_display; other findings are pathless. Keep whole-file exclusions and serialized Finding unchanged. Extract portability finding conversion/sort into `portability/findings.rs`; portability.rs and new modules must finish below 1000 non-test lines.
4. Render the map as an inline TOML table with quoted keys; subtable input remains equivalent. Add schema-driven additionalProperties value validation. Preserve installer rejection of unknown rule names via a Rust-generated `analyzer-catalog.json`, never a hand-maintained Python catalog: `python3 tools/generate_installer_catalog.py` invokes each analyzer's explicitly ignored Rust `emit_installer_catalog` test with a temporary output path and combines their live RuleCatalog slices deterministically. Normal `installer_catalog_matches_rust` tests only compare the artifact, never write. Installer uses generated exact IDs/family selectors generically; per-rule maps accept IDs only. Existing installer conflict exit remains 2; Rust config errors remain 3.
5. Port the PORT-007 failing literal pattern from atm-core fenix c983f96a301af01ea584bc0ec1bc7b2cca5a9742 `crates/atm-herdr/src/transport_socket.rs::named_pipe_name` into `tests/fixtures/issue385.rs` in portability; add a Unix absolute literal to prove PORT-006 survives. Its `sc-lint.toml` records #385's whole-file workaround, not an upstream per-rule implementation/test. Consumer names become neutral fixtures. Add the same rendered-input Rust parse and installer negative tests; Python gains no independent Rust rule implementation.

### Shared interfaces
```rust
pub struct RepoRelativePath(String); // normalized slash path; private storage
impl RepoRelativePath { pub fn parse(value: &str) -> Result<Self, RelativePathError>; }
impl AnalyzerSettings {
    pub fn own_tables(&self, key: &str) -> Result<Option<Vec<&toml::Table>>, AnalyzerConfigError>;
    pub fn apply_with_paths<R>(&self, findings: impl IntoIterator<Item=(Finding<R>, Option<RepoRelativePath>)>, rule: impl Fn(&R)->CatalogRuleId) -> (Vec<Finding<R>>, ReportStatus);
}
```
Paths normalize backslashes and reject absolute/escaping components at construction; analyzer-owned adapters provide relative_slash_path(root, source_path). Pathless/nonmatching findings survive the new map. Shared support neither reads diagnostic messages nor decodes owner IDs. Export new neutral types through support lib.rs and its boundary roots; no analyzer dependency edges. Each analyzer retains its current rule adapter and public analysis signature.

## Authoritative acceptance criteria
1. `issue385_rule_path_exclusion_retains_other_rule` in portability src/tests.rs first reproduces the reported #385 consumer failure against the attributed fixture: PORT-007 incorrectly rejects its intentional named-pipe literal, and the current whole-file workaround also hides PORT-006. After the fix, the same fixture with its per-rule exclusion must suppress only PORT-007 and retain PORT-006. Also verify that the baseline rejects the new config key. Retain the failing-before/passing-after command, status and rule IDs as the issue-linked regression evidence.
2. `issue385_runtime_paths` and `issue385_boundary_manifest_paths` in the respective src/tests.rs prove actual callers, whole-file precedence, Windows separators, pathless/nonmatching survival, and the optional map branches: when supplied, apply its per-rule patterns; when absent, preserve prior findings byte-for-byte for identical inputs; an empty map behaves as absent.
3. Support src/tests.rs `issue385_config_matrix` covers every D1 failure, map filtering/status and `own_tables` absent/empty/non-array/non-table cases. `test_issue385_installer_roundtrip` in tests/adoption/test_install.py covers quoted IDs, schema value rejection, generated-catalog unknown/family rejection and parse-equivalent TOML in Rust.
4. `installer_catalog_matches_rust` in each analyzer src/tests.rs rejects stale generated catalog slices; `test_installer_has_no_rule_constants` in tests/adoption/test_install.py rejects catalog-ID literals in executable installer code (generated artifact/test fixtures excluded). Update boundary record review gates for this bounded invariant.

## Unblock Milestone
Committed support API, caller tests and generated-catalog drift checks unblock k2/k3; k4 later consumes the same own_tables API. This is the existing sprint acceptance, not a new gate.

## Authoritative validation
`cargo test -p sc-lint-analyzer-support issue385`; `cargo test -p sc-lint-portability issue385`; `cargo test -p sc-lint-runtime issue385`; `cargo test -p sc-lint-boundary issue385`; per-analyzer `cargo test -p <crate> installer_catalog_matches_rust`; `python3 -m unittest discover -s tests/adoption -p test_install.py`. Finish `just lint`, then `just test`.

## Non-closure
No publishing, version bump, report-schema change, consumer-specific defaults, unrelated tooling or skill changes. Final user guides and release notes belong solely to k10; governing amendments land in planning before dispatch.
