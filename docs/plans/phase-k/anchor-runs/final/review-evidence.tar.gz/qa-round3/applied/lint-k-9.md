# Sprint k-9 — platform-profile-execution

## Scope
Issues #199 plus execution half of #197; 12–22h. Keep this as one sprint because the typed selection result, host execution, and serialized workflow rows are one end-to-end contract and must agree. Size the six deliverables: D1 planner/API and structured errors 3–5h; D2 config semantics and round-trip 2–4h; D3 selection/bootstrap grammar 2–4h; D4 execution and workflow output 2–4h; D5 integration/reuse 1–2h; D6 upstream port and golden cases 2–3h. k-7 owns provisioning; k-9 selects/executes already-declared steps. Close #197 only after both halves land. Existing simpler consumers continue to run sc-lint without atm-core-specific configuration. Preserve unrelated-consumer behavior and Native/Xwin source-maintainer profiles. User docs (including docs-bundle guide) belong to k-10; executable help in `print_help.py` remains k-9.

## Deliverables
1. Add `crates/sc-lint/src/profile_plan.rs` and `lib.rs` module registration; keep `config.rs` and `workflow.rs` below 1000 non-test lines. Use these concrete types in `profile_plan.rs` (fields may be private with constructors/accessors):
```rust
struct ProfileName(String); // validated nonempty semantic name
struct Target(String); // validated rust target triple
enum Platform { Linux, MacOS, Windows }
enum PlatformScope { Host, All, Named(Platform) }
enum CargoVerb { Check, Clippy }
struct PlannedStep { name: String, command: OsString, args: Vec<OsString>, platform: Option<Platform>, target: Option<Target>, cargo_verb: Option<CargoVerb> }
enum SkipReason { UnsupportedCrossCommand, UnsupportedCrossTarget }
struct SkipRecord { name: String, host: Platform, platform: Platform, target: Option<Target>, reason: SkipReason }
enum ProfilePlanDetailCode { EmptyMembers, DuplicateMember, UnknownMember, AmbiguousName, UnknownStepField, TargetRequiresPlatform, TargetOsMismatch, UnsupportedCommandShape }
const PROFILE_PLAN_ERROR_CODE: &str = "CLI.SC_LINT_PROFILE_CONFIG_INVALID";
struct ProfilePlanError { code: &'static str, detail_code: ProfilePlanDetailCode, step: Option<String>, field: Option<String>, cause: String, recovery: String, docs: Option<String> }
```
`ProfileName::parse(value: String) -> Result<Self, ProfilePlanError>` rejects empty names; `Target::parse(value: String) -> Result<Self, ProfilePlanError>` validates triples; `CargoVerb` is derived only from literal cargo `check`/`clippy` argv. Current `ConsumerProfileStep` fields are `name: String` and `command: Vec<String>`; its decoded config representation gains `platform: Option<Platform>` and `target: Option<Target>` after exact-key/shape checking. Set the error `code` to `PROFILE_PLAN_ERROR_CODE`; the struct carries one detail code, step/field, cause, recovery, and docs reference. Planner API: `plan_consumer_lint(steps: &[ConsumerProfileStep], selector: Option<&ProfileName>, scope: PlatformScope, host: Platform) -> Result<Vec<PlanDecision>, ProfilePlanError>`. `PlanDecision::{Run(PlannedStep), Skip(SkipRecord)}` preserves declaration order; `ProfilePlanDetailCode` maps one-to-one in the listed order to stable strings `PROFILE.EMPTY_MEMBERS`, `PROFILE.DUPLICATE_MEMBER`, `PROFILE.UNKNOWN_MEMBER`, `PROFILE.AMBIGUOUS_NAME`, `PROFILE.UNKNOWN_STEP_FIELD`, `PROFILE.TARGET_REQUIRES_PLATFORM`, `PROFILE.TARGET_OS_MISMATCH`, and `PROFILE.UNSUPPORTED_COMMAND_SHAPE`; invalid input returns this structured error without panicking. In `workflow.rs`, retain the existing trait methods `fn cargo_xwin_available(&self, repo_root: &Path) -> bool` and `fn run_step(&self, repo_root: &Path, step: &StepPlan) -> Result<StepReport, CliError>`; add `fn host_platform(&self) -> Platform` and `fn run_planned_step(&self, repo_root: &Path, step: &PlannedStep) -> Result<StepReport, CliError>`. `HostSystemAdapter` implements the additions, converting `PlannedStep` to the existing `StepPlan` as needed. Keep sequential fail-fast/report behavior. The planner owns pure selection/skip decisions; `workflow.rs` owns serialization of `PlanDecision::Run` and `PlanDecision::Skip` into the existing workflow JSON `steps` array, including the specified skipped-row fields.
2. Parse and validate profile/step semantics once in Rust. Python `install.py`/`install.schema.json` performs JSON shape checks only (types/exact keys); well-shaped semantic-invalid values render and are rejected by Rust loader. Profiles are ordered names of existing steps, not nested profiles; reject empty/duplicate/unknown members and step/profile collisions or reserved `all`. Preserve existing install `profiles` name-to-argv form; additive step objects have exactly `command` and optional `platform`/`target`. `lint_profiles` is a separate name-to-ordered-step-list map. Runtime TOML keeps existing `[[tool.sc-lint.lint]]` rows and adds `[tool.sc-lint.lint_profiles]`. Example round-trip:
```json
{"profiles":{"format":["cargo","fmt","--check"],"native-check":["cargo","check","--workspace"],"windows-check":{"command":["cargo","check","--workspace"],"platform":"windows","target":"x86_64-pc-windows-msvc"}},"lint_profiles":{"ci":["format","native-check","windows-check"]}}
```
```toml
[tool.sc-lint.lint_profiles]
ci = ["format", "native-check", "windows-check"]
[[tool.sc-lint.lint]]
name = "format"
command = ["cargo", "fmt", "--check"]
[[tool.sc-lint.lint]]
name = "native-check"
command = ["cargo", "check", "--workspace"]
[[tool.sc-lint.lint]]
name = "windows-check"
command = ["cargo", "check", "--workspace"]
platform = "windows"
target = "x86_64-pc-windows-msvc"
```
Target requires matching platform and literal cargo `check`/`clippy` argv; reject wrappers, embedded `--target`, other verbs. Preserve arguments after the cargo verb literally. Add no installer OS/target/verb policy.
3. Selection: `--profile` resolves step then named profile; collisions fail load; `all` and absent selector preserve legacy semantics. Absent optional profile configuration preserves prior step selection and results on identical input; supplied profile configuration is enforced when selected. Consumer-only `--platform-scope host|all|linux|macos|windows`, default host. Membership first; preserve order/no duplicates. All scopes include unannotated and host-matching steps; all adds all declarations; named scope selects that platform. A selected platform-tagged command without target runs only on its platform; an explicit cross selection skips with `unsupported_cross_command`. Nonselected steps are omitted, not reported as unsupported. Bootstrap grammar is `lint [selector] [scope] --config PATH`: one token always selector (`lint windows` means step selector), two means selector then scope; scope-only and >2 tokens are usage exit 2. Shell and PowerShell forward exact argv; existing single step selectors and `lint all` retain their meanings. Bootstrap `lint ci windows` forwards `--profile ci --platform-scope windows`.
4. Execution matrix: untagged and same-host/no-target use existing argv; same-host target uses cargo check/clippy + `--target` for any rustc-recognized same-platform triple; missing target/linker fails at execution, never skips. Linux/macOS→Windows MSVC x86_64 uses cargo xwin + `--target`; other cross combinations emit `unsupported_cross_target`. Missing xwin/rustup target or child failure on supported combinations fails. Use existing `ensure_xwin_available` failure behavior (no optional-xwin skip). Target OS mismatch/malformed declarations fail config. Skip-only runs exit 0 and emit ordered JSON `workflow` result `steps` rows with `status: skipped`, name, host, platform, target|null, and reason enum. The planner matrix tests all injected host/scope combinations; actual execution is host-runner only. Do not alter source-maintainer Native/Xwin rules: ADR-005's xwin exclusion concerns source-maintainer profiles; consumer-declared targets follow ADR-017 change 4.
5. Reuse k-6 `.sc-lint/bootstrap exec` managed activation/direct binary resolution and k-7 `sc_lint.setup_tools` plus persisted `.sc-lint/install.json` tools contract; own shared files changed here. Add root `.sc-lint/bootstrap(.ps1)`, generated parity test, installed wheel/binary test, and `bindings/sc-lint-py/python/sc_lint/print_help.py`. Rust tests in `crates/sc-lint/src/tests.rs`; planner matrix injects all three host values, while actual process execution runs only on each real host. Target/tool fixtures live in `crates/sc-lint/tests/fixtures/platform-profile-execution/`.
6. Port applicable `atm-core@c1f3ee7a86414aa58161fdf9c1c5bc5f5aef4569:.just/run_lint.py` `resolve_task_names`/`build_tasks` logic and named tests `test_resolve_task_names_all_includes_new_targets`, `test_resolve_task_names_rejects_unknown_target`, `test_resolve_task_names_fast_is_low_latency_subset`; preserve failing inputs/outcomes with neutral names. Upstream lacks host/scope/rustup fixtures; add those locally, no parallelism/constants. CLI example using the existing `LintTarget::Ci` and consumer `--profile` grammar: `sc-lint lint ci --consumer --profile ci --platform-scope all --config sc-lint.toml`; bootstrap `lint ci all`. Workflow: declared `ci` profile emits `just lint ci all` on Linux and `just lint ci` elsewhere; a lone `ci` step emits `just lint ci`; if neither a profile nor step named `ci` exists, leave the existing `just lint` invocation unchanged. Retain existing Just recipes; add no recipe. Golden cases belong to `tests/adoption/test_install.py`.

## Unblock Milestone
k-10 may start after k-9 commits the Rust profile loader/planner API, bootstrap selector/scope contract, and CI workflow behavior. This is the concrete documentation handoff, not an added gate.

## Acceptance and validation
1. AC1 (D1, D6): Run the named upstream regressions plus `test_profile_platform_scope_matrix`, `test_profile_selection_order_and_no_duplicates`, `test_profile_rejects_invalid_members_and_targets`, `test_profile_emits_structured_skips_and_skip_only_success`, `test_supported_execution_failure_is_nonzero`, `test_profiles_exact_json_toml_roundtrip`, `test_installer_shape_only_rust_semantic_rejection`, `test_bootstrap_selector_scope_grammar_parity`, `test_ci_workflow_resolution_golden`, and `test_consumer_profile_installed_wheel_and_binary`.
2. AC2 (D1, D4, D6): Name issue-linked red/green cases `test_issue_199_named_membership_reproduces_then_passes` and `test_issue_197_cross_target_execution_reproduces_then_passes`; test the halves separately with a neutral workspace and adapted atm-core inputs.
3. AC3 (D2–D5): Preserve the installer shape-only boundary, optional-config compatibility, sequential execution and JSON reporting contracts described above; add no Python lint semantics or duplicate Rust/Python validator. Run focused tests, `just lint`, and `just test`.

## Non-closure
No publishing/version bump, sc-publish changes, unconditional wheel CI, new runner/framework, setup hooks, interpreter policy, generic groups, keep-going, parallel execution, or independent #195/#196/#198.
