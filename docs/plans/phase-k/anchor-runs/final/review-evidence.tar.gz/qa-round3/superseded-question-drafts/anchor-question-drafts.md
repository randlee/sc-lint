# Phase K draft Jev questions

Status: historical drafts, superseded by the independently tuned and accepted sets in anchor-questions.md. These drafts are not used as question overrides.

## ANC-001

### plan / relevant

Does `item.text` describe planning work on reuse of atm-core source for the same reported lint gap? Use `anchor.scope` to identify applicability. Judge subject overlap only.

- yes: The item plans or depends on reuse of atm-core source for the same reported lint gap.
- no: The item covers a different component or activity and could neither follow nor conflict with this anchor.
- unclear: The item is too vague to tell whether it touches the governed work.

### plan / addressed

Does `item.text` explicitly plan to reuse matching atm-core source when it can be adapted to sc-lint boundaries without embedding atm-core-only policy? Judge the planned obligation itself; a topical mention or silence does not establish it.

- yes: The plan states that the matching upstream source is named as the implementation starting point and its repository-specific policy is moved to consumer configuration.
- no: The item only mentions the topic or is silent about this obligation.
- unclear: The item suggests the obligation but leaves its actual planned approach indeterminate.

### plan / contradicted

Does `item.text` explicitly plan an approach that conflicts with the obligation in `anchor.statement`? Silence about reuse of atm-core source for the same reported lint gap is not a conflict.

- yes: The plan states that the item explicitly starts a fresh implementation despite identifying adaptable atm-core source for the same behavior.
- no: No described plan conflicts with the anchor, whether or not the item addresses it.
- unclear: The described approach may conflict, but its decisive detail is ambiguous.

### dev / relevant

Does the delivered work in `item.text` change or depend on reuse of atm-core source for the same reported lint gap? Judge subject overlap only.

- yes: The described work changes or depends on reuse of atm-core source for the same reported lint gap.
- no: The work concerns a different component or activity and could neither follow nor violate this anchor.
- unclear: The work description is too vague to determine applicability.

### dev / implemented

Does `item.text` say the delivered work actually did this: reuse matching atm-core source when it can be adapted to sc-lint boundaries without embedding atm-core-only policy? Judge the implementation claim, not its evidence.

- yes: The delivered-work account states that the matching upstream source is named as the implementation starting point and its repository-specific policy is moved to consumer configuration.
- no: The account is silent, says the obligation was deferred, or describes only future plans.
- unclear: The account mentions the topic without making clear whether the obligation was implemented.

### dev / violated

Does `item.text` describe delivered work that conflicts with `anchor.statement`? Silence is not a violation.

- yes: The delivered-work account states that the item explicitly starts a fresh implementation despite identifying adaptable atm-core source for the same behavior.
- no: Nothing in the described work conflicts with the anchor, even if compliance is not claimed.
- unclear: A possible conflict is mentioned, but the decisive implementation detail is unclear.

### dev / evidenced

Where `item.text` claims compliance with `anchor.statement`, does it cite a checkable artifact supporting that claim? Look for the upstream source path, ported sc-lint path, and a source comparison or diff. Judge evidence only.

- yes: The compliance claim points to checkable evidence such as the upstream source path, ported sc-lint path, and a source comparison or diff.
- no: The claim has no checkable support, or no compliance claim is made.
- unclear: A possible artifact is mentioned but its connection to the compliance claim is unclear.

## ANC-002

### plan / relevant

Does `item.text` describe planning work on regression tests for behavior already tested in atm-core? Use `anchor.scope` to identify applicability. Judge subject overlap only.

- yes: The item plans or depends on regression tests for behavior already tested in atm-core.
- no: The item covers a different component or activity and could neither follow nor conflict with this anchor.
- unclear: The item is too vague to tell whether it touches the governed work.

### plan / addressed

Does `item.text` explicitly plan to reuse a matching atm-core test case while adapting its harness and inputs and retaining the reported failure and expected outcome? Judge the planned obligation itself; a topical mention or silence does not establish it.

- yes: The plan states that the upstream test and its input and expected outcome are identified as the regression case to port.
- no: The item only mentions the topic or is silent about this obligation.
- unclear: The item suggests the obligation but leaves its actual planned approach indeterminate.

### plan / contradicted

Does `item.text` explicitly plan an approach that conflicts with the obligation in `anchor.statement`? Silence about regression tests for behavior already tested in atm-core is not a conflict.

- yes: The plan states that the item explicitly replaces an available matching failure test with only unrelated or happy-path coverage.
- no: No described plan conflicts with the anchor, whether or not the item addresses it.
- unclear: The described approach may conflict, but its decisive detail is ambiguous.

### dev / relevant

Does the delivered work in `item.text` change or depend on regression tests for behavior already tested in atm-core? Judge subject overlap only.

- yes: The described work changes or depends on regression tests for behavior already tested in atm-core.
- no: The work concerns a different component or activity and could neither follow nor violate this anchor.
- unclear: The work description is too vague to determine applicability.

### dev / implemented

Does `item.text` say the delivered work actually did this: reuse a matching atm-core test case while adapting its harness and inputs and retaining the reported failure and expected outcome? Judge the implementation claim, not its evidence.

- yes: The delivered-work account states that the upstream test and its input and expected outcome are identified as the regression case to port.
- no: The account is silent, says the obligation was deferred, or describes only future plans.
- unclear: The account mentions the topic without making clear whether the obligation was implemented.

### dev / violated

Does `item.text` describe delivered work that conflicts with `anchor.statement`? Silence is not a violation.

- yes: The delivered-work account states that the item explicitly replaces an available matching failure test with only unrelated or happy-path coverage.
- no: Nothing in the described work conflicts with the anchor, even if compliance is not claimed.
- unclear: A possible conflict is mentioned, but the decisive implementation detail is unclear.

### dev / evidenced

Where `item.text` claims compliance with `anchor.statement`, does it cite a checkable artifact supporting that claim? Look for upstream and ported test paths, shared fixture inputs, and test output for the reported failure. Judge evidence only.

- yes: The compliance claim points to checkable evidence such as upstream and ported test paths, shared fixture inputs, and test output for the reported failure.
- no: The claim has no checkable support, or no compliance claim is made.
- unclear: A possible artifact is mentioned but its connection to the compliance claim is unclear.

## ANC-003

### plan / relevant

Does `item.text` describe planning work on implementation-language choice for Phase K tool logic? Use `anchor.scope` to identify applicability. Judge subject overlap only.

- yes: The item plans or depends on implementation-language choice for Phase K tool logic.
- no: The item covers a different component or activity and could neither follow nor conflict with this anchor.
- unclear: The item is too vague to tell whether it touches the governed work.

### plan / addressed

Does `item.text` describe a tool-language choice consistent with the Rust-where-appropriate preference in `anchor.statement`? Judge the choice described, not whether a written rationale is mandatory.

- yes: The item plans Rust for substantive tool logic, or describes a tool-specific reason another language is appropriate.
- no: The item gives no implementation-language choice or only names the tool without addressing language.
- unclear: The item names a non-Rust language but does not give enough information to judge whether Rust is appropriate for this tool.

### plan / contradicted

Does `item.text` explicitly reject Rust for substantive tool logic despite stating that Rust is appropriate for this tool and boundary? Silence or an unexplained non-Rust choice alone is not a contradiction.

- yes: The item says Rust is appropriate here but chooses non-Rust substantive logic anyway solely for convenience.
- no: The item does not explicitly make a choice inconsistent with its stated appropriateness judgment.
- unclear: The item offers potentially conflicting language reasons, but its actual choice or applicability is ambiguous.

### dev / relevant

Does the delivered work in `item.text` change or depend on implementation-language choice for Phase K tool logic? Judge subject overlap only.

- yes: The described work changes or depends on implementation-language choice for Phase K tool logic.
- no: The work concerns a different component or activity and could neither follow nor violate this anchor.
- unclear: The work description is too vague to determine applicability.

### dev / implemented

Does `item.text` say the delivered tool logic followed the Rust-where-appropriate preference? Judge the implementation described, not whether it documented a rationale.

- yes: The substantive tool logic is in Rust, or the work describes a tool-specific reason another language was appropriate.
- no: No delivered language choice or compliance claim is described.
- unclear: The logic is in another language, but the description does not establish whether Rust was appropriate for this tool.

### dev / violated

Does `item.text` show that the delivered tool used non-Rust substantive logic after explicitly establishing Rust was appropriate for that tool and boundary? Silence or lack of a written rationale alone is not a violation.

- yes: The account says Rust was appropriate but chose non-Rust rule logic solely for convenience.
- no: The account contains no explicit conflict with the Rust-where-appropriate preference.
- unclear: The account leaves the language choice or stated appropriateness ambiguous.

### dev / evidenced

Where `item.text` claims compliance with `anchor.statement`, does it cite a checkable artifact supporting that claim? Look for tool source paths, crate or binding boundaries, and a concrete explanation of the chosen language. Judge evidence only.

- yes: The compliance claim points to checkable evidence such as tool source paths, crate or binding boundaries, and a concrete explanation of the chosen language.
- no: The claim has no checkable support, or no compliance claim is made.
- unclear: A possible artifact is mentioned but its connection to the compliance claim is unclear.

## ANC-004

### plan / relevant

Does `item.text` describe planning work on Python bindings for Phase K tools whose rule logic is in Rust? Use `anchor.scope` to identify applicability. Judge subject overlap only.

- yes: The item plans or depends on Python bindings for Phase K tools whose rule logic is in Rust.
- no: The item covers a different component or activity and could neither follow nor conflict with this anchor.
- unclear: The item is too vague to tell whether it touches the governed work.

### plan / addressed

Does `item.text` explicitly plan to keep Python bindings to argument/result adaptation and Rust invocation without duplicating rule logic? Judge the planned obligation itself; a topical mention or silence does not establish it.

- yes: The plan states that the binding is described as forwarding inputs to Rust and translating its results, with substantive matching in Rust.
- no: The item only mentions the topic or is silent about this obligation.
- unclear: The item suggests the obligation but leaves its actual planned approach indeterminate.

### plan / contradicted

Does `item.text` explicitly plan an approach that conflicts with the obligation in `anchor.statement`? Silence about Python bindings for Phase K tools whose rule logic is in Rust is not a conflict.

- yes: The plan states that the item explicitly puts duplicate substantive matching logic in Python alongside the Rust implementation.
- no: No described plan conflicts with the anchor, whether or not the item addresses it.
- unclear: The described approach may conflict, but its decisive detail is ambiguous.

### dev / relevant

Does the delivered work in `item.text` change or depend on Python bindings for Phase K tools whose rule logic is in Rust? Judge subject overlap only.

- yes: The described work changes or depends on Python bindings for Phase K tools whose rule logic is in Rust.
- no: The work concerns a different component or activity and could neither follow nor violate this anchor.
- unclear: The work description is too vague to determine applicability.

### dev / implemented

Does `item.text` say the delivered work actually did this: keep Python bindings to argument/result adaptation and Rust invocation without duplicating rule logic? Judge the implementation claim, not its evidence.

- yes: The delivered-work account states that the binding is described as forwarding inputs to Rust and translating its results, with substantive matching in Rust.
- no: The account is silent, says the obligation was deferred, or describes only future plans.
- unclear: The account mentions the topic without making clear whether the obligation was implemented.

### dev / violated

Does `item.text` describe delivered work that conflicts with `anchor.statement`? Silence is not a violation.

- yes: The delivered-work account states that the item explicitly puts duplicate substantive matching logic in Python alongside the Rust implementation.
- no: Nothing in the described work conflicts with the anchor, even if compliance is not claimed.
- unclear: A possible conflict is mentioned, but the decisive implementation detail is unclear.

### dev / evidenced

Where `item.text` claims compliance with `anchor.statement`, does it cite a checkable artifact supporting that claim? Look for Rust rule source path, Python binding path, and a call path showing the binding delegates to Rust. Judge evidence only.

- yes: The compliance claim points to checkable evidence such as Rust rule source path, Python binding path, and a call path showing the binding delegates to Rust.
- no: The claim has no checkable support, or no compliance claim is made.
- unclear: A possible artifact is mentioned but its connection to the compliance claim is unclear.

## ANC-005

### plan / relevant

Does `item.text` describe planning work on consumer-specific policy in reusable Phase K lint rules? Use `anchor.scope` to identify applicability. Judge subject overlap only.

- yes: The item plans or depends on consumer-specific policy in reusable Phase K lint rules.
- no: The item covers a different component or activity and could neither follow nor conflict with this anchor.
- unclear: The item is too vague to tell whether it touches the governed work.

### plan / addressed

Does `item.text` explicitly plan to obtain consumer-specific policy from configuration instead of branching on atm-core repository identity? Judge the planned obligation itself; a topical mention or silence does not establish it.

- yes: The plan states that the rule reads any consumer-specific policy from configuration and runs without an atm-core identity check.
- no: The item only mentions the topic or is silent about this obligation.
- unclear: The item suggests the obligation but leaves its actual planned approach indeterminate.

### plan / contradicted

Does `item.text` explicitly plan an approach that conflicts with the obligation in `anchor.statement`? Silence about consumer-specific policy in reusable Phase K lint rules is not a conflict.

- yes: The plan states that the item explicitly hard-codes an atm-core repository-name branch or its policy into shared rule logic.
- no: No described plan conflicts with the anchor, whether or not the item addresses it.
- unclear: The described approach may conflict, but its decisive detail is ambiguous.

### dev / relevant

Does the delivered work in `item.text` change or depend on consumer-specific policy in reusable Phase K lint rules? Judge subject overlap only.

- yes: The described work changes or depends on consumer-specific policy in reusable Phase K lint rules.
- no: The work concerns a different component or activity and could neither follow nor violate this anchor.
- unclear: The work description is too vague to determine applicability.

### dev / implemented

Does `item.text` say the delivered work actually did this: obtain consumer-specific policy from configuration instead of branching on atm-core repository identity? Judge the implementation claim, not its evidence.

- yes: The delivered-work account states that the rule reads any consumer-specific policy from configuration and runs without an atm-core identity check.
- no: The account is silent, says the obligation was deferred, or describes only future plans.
- unclear: The account mentions the topic without making clear whether the obligation was implemented.

### dev / violated

Does `item.text` describe delivered work that conflicts with `anchor.statement`? Silence is not a violation.

- yes: The delivered-work account states that the item explicitly hard-codes an atm-core repository-name branch or its policy into shared rule logic.
- no: Nothing in the described work conflicts with the anchor, even if compliance is not claimed.
- unclear: A possible conflict is mentioned, but the decisive implementation detail is unclear.

### dev / evidenced

Where `item.text` claims compliance with `anchor.statement`, does it cite a checkable artifact supporting that claim? Look for rule and configuration paths plus checks in more than one consumer configuration. Judge evidence only.

- yes: The compliance claim points to checkable evidence such as rule and configuration paths plus checks in more than one consumer configuration.
- no: The claim has no checkable support, or no compliance claim is made.
- unclear: A possible artifact is mentioned but its connection to the compliance claim is unclear.

## ANC-006

### plan / relevant

Does `item.text` plan a Phase K rule with optional consumer policy, supplied in its chosen configuration form? Judge applicability only.

- yes: The item plans a rule whose behavior depends on optional consumer policy supplied in a configuration table or file.
- no: The item covers a different component or activity and could neither follow nor conflict with this anchor.
- unclear: The item is too vague to tell whether it touches the governed work.

### plan / addressed

Does `item.text` plan to enforce optional consumer policy when supplied and retain the prior result for that policy when absent? Either supported configuration form is sufficient. Judge this planned behavior only.

- yes: The plan specifies that supplied optional policy is enforced and its absence alone leaves the prior result unchanged.
- no: The item merely names optional policy or is silent about the supplied and absent behavior.
- unclear: The item mentions supplied or absent policy but leaves one outcome indeterminate.

### plan / contradicted

Does `item.text` explicitly plan to ignore supplied optional policy or change a result solely because optional policy is absent? Silence is not conflict; choosing a configuration table or a file is not conflict.

- yes: The plan ignores a supplied optional policy or changes behavior solely because that policy is absent.
- no: The plan contains no explicit conflict with supplied/absent optional-policy behavior.
- unclear: The decisive supplied or absent outcome is ambiguous.

### dev / relevant

Does the delivered work in `item.text` implement a rule with optional consumer policy in its chosen configuration form? Judge applicability only.

- yes: The work implements optional consumer policy supplied through a configuration table or file.
- no: The work concerns a different component or activity and could neither follow nor violate this anchor.
- unclear: The work description is too vague to determine applicability.

### dev / implemented

Does `item.text` say the delivered rule enforces optional policy when supplied and retains the prior result for that policy when absent? Either supported configuration form is sufficient. Judge the implementation claim, not evidence.

- yes: The account says supplied optional policy is enforced and its absence alone leaves the prior result unchanged.
- no: The account is silent about one or both outcomes or says they remain future work.
- unclear: The account mentions optional policy but does not make the supplied or absent outcome clear.

### dev / violated

Does `item.text` show that delivered work ignores supplied optional policy or changes a result solely because that policy is absent? Silence is not a violation; choosing a configuration table or file is not a violation.

- yes: The delivered rule ignores supplied optional policy or changes behavior solely because optional policy is absent.
- no: No described behavior conflicts with the supplied/absent rule.
- unclear: The account leaves the decisive supplied or absent outcome ambiguous.

### dev / evidenced

Where `item.text` claims correct optional-policy behavior, does it cite checkable configuration and tests for both supplied and absent cases? Either configuration table or file is sufficient. Judge evidence only.

- yes: The claim cites a configuration example and tests showing enforcement when supplied and prior behavior when absent.
- no: The claim has no checkable configuration or test evidence, or no compliance claim is made.
- unclear: Possible evidence is cited, but it does not clearly cover both supplied and absent outcomes.

## ANC-007

### plan / relevant

Does `item.text` describe planning work on simpler consumers that do not provide atm-core-specific configuration? Use `anchor.scope` to identify applicability. Judge subject overlap only.

- yes: The item plans or depends on simpler consumers that do not provide atm-core-specific configuration.
- no: The item covers a different component or activity and could neither follow nor conflict with this anchor.
- unclear: The item is too vague to tell whether it touches the governed work.

### plan / addressed

Does `item.text` explicitly plan to allow those consumers to run sc-lint without atm-core-specific configuration? Judge the planned obligation itself; a topical mention or silence does not establish it.

- yes: The plan states that the consumer runs its lint checks without an atm-core manifest or settings, including intended bug-fix behavior.
- no: The item only mentions the topic or is silent about this obligation.
- unclear: The item suggests the obligation but leaves its actual planned approach indeterminate.

### plan / contradicted

Does `item.text` explicitly plan an approach that conflicts with the obligation in `anchor.statement`? Silence about simpler consumers that do not provide atm-core-specific configuration is not a conflict.

- yes: The plan states that the item explicitly requires an atm-core manifest or setting before a simpler consumer can run.
- no: No described plan conflicts with the anchor, whether or not the item addresses it.
- unclear: The described approach may conflict, but its decisive detail is ambiguous.

### dev / relevant

Does the delivered work in `item.text` change or depend on simpler consumers that do not provide atm-core-specific configuration? Judge subject overlap only.

- yes: The described work changes or depends on simpler consumers that do not provide atm-core-specific configuration.
- no: The work concerns a different component or activity and could neither follow nor violate this anchor.
- unclear: The work description is too vague to determine applicability.

### dev / implemented

Does `item.text` say the delivered work actually did this: allow those consumers to run sc-lint without atm-core-specific configuration? Judge the implementation claim, not its evidence.

- yes: The delivered-work account states that the consumer runs its lint checks without an atm-core manifest or settings, including intended bug-fix behavior.
- no: The account is silent, says the obligation was deferred, or describes only future plans.
- unclear: The account mentions the topic without making clear whether the obligation was implemented.

### dev / violated

Does `item.text` describe delivered work that conflicts with `anchor.statement`? Silence is not a violation.

- yes: The delivered-work account states that the item explicitly requires an atm-core manifest or setting before a simpler consumer can run.
- no: Nothing in the described work conflicts with the anchor, even if compliance is not claimed.
- unclear: A possible conflict is mentioned, but the decisive implementation detail is unclear.

### dev / evidenced

Where `item.text` claims compliance with `anchor.statement`, does it cite a checkable artifact supporting that claim? Look for a no-atm-core-configuration consumer fixture and its lint execution result. Judge evidence only.

- yes: The compliance claim points to checkable evidence such as a no-atm-core-configuration consumer fixture and its lint execution result.
- no: The claim has no checkable support, or no compliance claim is made.
- unclear: A possible artifact is mentioned but its connection to the compliance claim is unclear.

## ANC-008

### plan / relevant

Does `item.text` describe planning work on traceability of a gap-fix sprint to the reported consumer failure? Use `anchor.scope` to identify applicability. Judge subject overlap only.

- yes: The item plans or depends on traceability of a gap-fix sprint to the reported consumer failure.
- no: The item covers a different component or activity and could neither follow nor conflict with this anchor.
- unclear: The item is too vague to tell whether it touches the governed work.

### plan / addressed

Does `item.text` explicitly plan to link the reported failure to its GitHub issue and a regression test reproducing that failure? Judge the planned obligation itself; a topical mention or silence does not establish it.

- yes: The plan states that the issue reference and a test for the issue’s reported failure are both identified.
- no: The item only mentions the topic or is silent about this obligation.
- unclear: The item suggests the obligation but leaves its actual planned approach indeterminate.

### plan / contradicted

Does `item.text` explicitly plan an approach that conflicts with the obligation in `anchor.statement`? Silence about traceability of a gap-fix sprint to the reported consumer failure is not a conflict.

- yes: The plan states that the item explicitly declines to test the reported failure or replaces its issue link with an unrelated issue.
- no: No described plan conflicts with the anchor, whether or not the item addresses it.
- unclear: The described approach may conflict, but its decisive detail is ambiguous.

### dev / relevant

Does the delivered work in `item.text` change or depend on traceability of a gap-fix sprint to the reported consumer failure? Judge subject overlap only.

- yes: The described work changes or depends on traceability of a gap-fix sprint to the reported consumer failure.
- no: The work concerns a different component or activity and could neither follow nor violate this anchor.
- unclear: The work description is too vague to determine applicability.

### dev / implemented

Does `item.text` say the delivered work actually did this: link the reported failure to its GitHub issue and a regression test reproducing that failure? Judge the implementation claim, not its evidence.

- yes: The delivered-work account states that the issue reference and a test for the issue’s reported failure are both identified.
- no: The account is silent, says the obligation was deferred, or describes only future plans.
- unclear: The account mentions the topic without making clear whether the obligation was implemented.

### dev / violated

Does `item.text` describe delivered work that conflicts with `anchor.statement`? Silence is not a violation.

- yes: The delivered-work account states that the item explicitly declines to test the reported failure or replaces its issue link with an unrelated issue.
- no: Nothing in the described work conflicts with the anchor, even if compliance is not claimed.
- unclear: A possible conflict is mentioned, but the decisive implementation detail is unclear.

### dev / evidenced

Where `item.text` claims compliance with `anchor.statement`, does it cite a checkable artifact supporting that claim? Look for the GitHub issue reference, named regression test, and failing-before/fixed-after result. Judge evidence only.

- yes: The compliance claim points to checkable evidence such as the GitHub issue reference, named regression test, and failing-before/fixed-after result.
- no: The claim has no checkable support, or no compliance claim is made.
- unclear: A possible artifact is mentioned but its connection to the compliance claim is unclear.

## ANC-009

### plan / relevant

Does `item.text` describe planning work on scope of Phase K changes, including fenix@atm-dev gaps and explicitly requested issues #197 and #199? Use `anchor.scope` to identify applicability. Judge subject overlap only.

- yes: The item plans or depends on scope of Phase K changes, including fenix@atm-dev gaps and explicitly requested issues #197 and #199.
- no: The item covers a different component or activity and could neither follow nor conflict with this anchor.
- unclear: The item is too vague to tell whether it touches the governed work.

### plan / addressed

Does `item.text` explicitly plan to limit work to those gaps and issues plus directly necessary implementation, configuration, and tests? Judge the planned obligation itself; a topical mention or silence does not establish it.

- yes: The plan states that the work is tied to a reported gap or #197/#199 and consists of its necessary implementation, configuration, or tests.
- no: The item only mentions the topic or is silent about this obligation.
- unclear: The item suggests the obligation but leaves its actual planned approach indeterminate.

### plan / contradicted

Does `item.text` explicitly plan an approach that conflicts with the obligation in `anchor.statement`? Silence about scope of Phase K changes, including fenix@atm-dev gaps and explicitly requested issues #197 and #199 is not a conflict.

- yes: The plan states that the item explicitly includes unrelated tooling, agent-skill changes, or a new team process.
- no: No described plan conflicts with the anchor, whether or not the item addresses it.
- unclear: The described approach may conflict, but its decisive detail is ambiguous.

### dev / relevant

Does the delivered work in `item.text` change or depend on scope of Phase K changes, including fenix@atm-dev gaps and explicitly requested issues #197 and #199? Judge subject overlap only.

- yes: The described work changes or depends on scope of Phase K changes, including fenix@atm-dev gaps and explicitly requested issues #197 and #199.
- no: The work concerns a different component or activity and could neither follow nor violate this anchor.
- unclear: The work description is too vague to determine applicability.

### dev / implemented

Does `item.text` say the delivered work actually did this: limit work to those gaps and issues plus directly necessary implementation, configuration, and tests? Judge the implementation claim, not its evidence.

- yes: The delivered-work account states that the work is tied to a reported gap or #197/#199 and consists of its necessary implementation, configuration, or tests.
- no: The account is silent, says the obligation was deferred, or describes only future plans.
- unclear: The account mentions the topic without making clear whether the obligation was implemented.

### dev / violated

Does `item.text` describe delivered work that conflicts with `anchor.statement`? Silence is not a violation.

- yes: The delivered-work account states that the item explicitly includes unrelated tooling, agent-skill changes, or a new team process.
- no: Nothing in the described work conflicts with the anchor, even if compliance is not claimed.
- unclear: A possible conflict is mentioned, but the decisive implementation detail is unclear.

### dev / evidenced

Where `item.text` claims compliance with `anchor.statement`, does it cite a checkable artifact supporting that claim? Look for issue or gap references and a changed-file list showing each change belongs to that work. Judge evidence only.

- yes: The compliance claim points to checkable evidence such as issue or gap references and a changed-file list showing each change belongs to that work.
- no: The claim has no checkable support, or no compliance claim is made.
- unclear: A possible artifact is mentioned but its connection to the compliance claim is unclear.
